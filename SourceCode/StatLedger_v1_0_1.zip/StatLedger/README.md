# StatLedger

One place to set your stat priority for each class and spec. Other addons read it from here
instead of keeping their own lists.

- Each of the 27 class/spec combinations has a built-in default priority.
- Customising a spec starts from that default, so changing one slot leaves the others as they were.
- Customisations are saved account-wide, keyed by class and spec (`StatLedgerDB`).
- Your spec is the talent tree with the most points (the class's usual tree before any talents).

Open with `/statledger`, or from Options > AddOns > StatLedger. Pick a class and spec, then drag
stats into order. X moves a stat under "Removed", where it stays visible so you can drag it back
(or press + to add it to the bottom).

| Command | |
|---|---|
| `/statledger` | Open the settings page on your spec |
| `/statledger show` | Print your current priority |
| `/statledger reset` | Reset your current spec to its default |

## For addon authors

Add `## OptionalDeps: StatLedger` to your TOC so it loads first, then check for the global:

```lua
if StatLedger and StatLedger.API_VERSION >= 1 then
    local stats = StatLedger:GetPriority()       -- { "SP", "FIRE", "SPELLCRIT", ... }
    local weights = StatLedger:GetWeights()      -- { SP = 1.0, FIRE = 0.87, ... }
    StatLedger:RegisterCallback("MyAddon", function(event, class, spec)
        -- "PRIORITY_CHANGED" or "SPEC_CHANGED": re-read and refresh
    end)
end
```

`class` is a class token (`"MAGE"`), `spec` a talent tab index (1-3). Both default to the
player's when left out. Getters return copies.

| Function | Returns |
|---|---|
| `:GetActiveSpec()` | `class, spec, specName` |
| `:GetPriority(class, spec)` | Ordered stat keys, best first: your custom list, else the default |
| `:GetDefaultPriority(class, spec)` | The built-in list |
| `:GetWeights(class, spec)` | `{ [stat] = weight }`, 1st = 1.0 falling evenly to 0.1 at the last; unlisted stats absent |
| `:IsCustom(class, spec)` | Whether the spec has been customised |
| `:SetPriority(class, spec, list)` | Replace the whole list |
| `:SetSlot(class, spec, slot, stat)` | Set one slot (a listed stat moves; `"NONE"` clears) |
| `:MoveStat(class, spec, from, to)` | Reorder |
| `:InsertStat(class, spec, stat, index)` | Put a stat at a rank (moves it if already listed) |
| `:RemoveStat(class, spec, stat)` | Take a stat out of the ranked list |
| `:GetRemovedStats(class, spec)` | Stats not in the ranked list |
| `:ResetPriority(class, spec)` | Back to the default |
| `:Describe(class, spec)` | `"Spell Power > Fire Spell Power > ..."` |
| `:GetStats()`, `:GetStatLabel(stat)` | All stat keys, display names |
| `:GetClasses()`, `:GetClassName(class)`, `:GetSpecs(class)`, `:GetSpecName(class, spec)` | Class/spec metadata |
| `:RegisterCallback(owner, fn)`, `:UnregisterCallback(owner)` | `fn(event, class, spec)` |

Stat keys: STR AGI STA INT SPI AP RAP SP HEAL FIRE FROST SHADOW ARCANE NATURE CRIT SPELLCRIT
HIT HASTE MP5 ARMOR DEF DODGE PARRY BLOCK BLOCKVALUE DPS. Ignore keys your addon doesn't score.
