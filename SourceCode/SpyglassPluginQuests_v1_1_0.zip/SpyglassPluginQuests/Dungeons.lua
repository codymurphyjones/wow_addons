local _, ns = ...

-- Which quests belong to which dungeon or raid, worked out from QuestieDB.
-- A quest belongs to an instance when its zone is the instance, its giver
-- stands inside, or something it asks for is only found there: a creature to
-- kill or talk to, an object, or an item that drops from one of them. Built once, a few hundred quests per frame, the first time the
-- journal's Quests tab is opened.
local D = {}
ns.Dungeons = D

local DB = LibQuestieDB
local PER_FRAME = 250
local MAX_DROPPERS = 25 -- items dropped by more creatures than this are too common to place

local byArea          -- [areaID] = { questID, ... }
local npcsOf = {}     -- [questID] = { [npcID] = true } creatures the quest involves
local building = false

local npcAreas, objectAreas = {}, {}

-- The areas a creature (or object) has spawns in.
local function Areas(cache, entity, id)
    local cached = cache[id]
    if cached then return cached end
    local list = {}
    local spawns = entity and entity.Get(id, "spawns")
    if type(spawns) == "table" then
        for area in pairs(spawns) do list[#list + 1] = area end
    end
    cache[id] = list
    return list
end

local function AddArea(set, area)
    if type(area) == "number" and area > 0 then set[area] = true end
end

-- Creatures and objects place a quest only when they're found in one area:
-- a dungeon's own inhabitants, not mobs that also roam outside.
local function AddOnly(set, list)
    if #list == 1 then AddArea(set, list[1]) end
end

-- The areas a quest touches, and the creatures it involves.
local function Index(questID)
    local Q = DB.Quest
    local areas, npcs = {}, {}
    AddArea(areas, Q.Get(questID, "zoneOrSort"))

    local function Npc(id)
        if type(id) ~= "number" then return end
        npcs[id] = true
        AddOnly(areas, Areas(npcAreas, DB.Npc, id))
    end
    local function Object(id)
        if type(id) ~= "number" then return end
        AddOnly(areas, Areas(objectAreas, DB.Object, id))
    end

    local started = Q.Get(questID, "startedBy")
    if type(started) == "table" then
        for _, id in ipairs(type(started[1]) == "table" and started[1] or {}) do
            AddOnly(areas, Areas(npcAreas, DB.Npc, id))
        end
        for _, id in ipairs(type(started[2]) == "table" and started[2] or {}) do Object(id) end
    end

    local objectives = Q.Get(questID, "objectives")
    if type(objectives) == "table" then
        for _, o in ipairs(type(objectives[1]) == "table" and objectives[1] or {}) do Npc(o[1]) end
        for _, o in ipairs(type(objectives[2]) == "table" and objectives[2] or {}) do Object(o[1]) end
        for _, o in ipairs(type(objectives[3]) == "table" and objectives[3] or {}) do
            local item = o[1]
            if type(item) == "number" and DB.Item then
                local droppers = DB.Item.Get(item, "npcDrops")
                if type(droppers) == "table" and #droppers <= MAX_DROPPERS then
                    for _, id in ipairs(droppers) do Npc(id) end
                end
                local objects = DB.Item.Get(item, "objectDrops")
                if type(objects) == "table" and #objects <= MAX_DROPPERS then
                    for _, id in ipairs(objects) do Object(id) end
                end
            end
        end
        -- Kill credit: { { creatureIDs }, creditID, text }
        for _, o in ipairs(type(objectives[5]) == "table" and objectives[5] or {}) do
            if type(o[1]) == "table" then
                for _, id in ipairs(o[1]) do Npc(id) end
            end
        end
    end
    return areas, npcs
end

-- Builds the index over a few frames; SpyGlass redraws when done.
function D:Build()
    if byArea or building or not (DB and DB.Quest) then return end
    building = true
    local ids, index, result = DB.Quest.GetAllIds(), 1, {}
    C_Timer.NewTicker(0.01, function(ticker)
        local last = math.min(index + PER_FRAME - 1, #ids)
        for i = index, last do
            local questID = ids[i]
            local ok, areas, npcs = pcall(Index, questID)
            if ok then
                npcsOf[questID] = npcs
                for area in pairs(areas) do
                    local list = result[area]
                    if not list then
                        list = {}
                        result[area] = list
                    end
                    list[#list + 1] = questID
                end
            end
        end
        index = last + 1
        if index > #ids then
            ticker:Cancel()
            byArea, building = result, false
            SpyGlass:RequestRefresh()
        end
    end)
end

function D:Ready()
    return byArea ~= nil
end

-- The instance's area: AtlasLoot's area ID, else Questie's name lookup.
local function AreaOf(inst)
    if inst.areaID then return inst.areaID end
    if QuestieLoader and QuestieLoader.ImportModule then
        local ok, zoneDB = pcall(QuestieLoader.ImportModule, QuestieLoader, "ZoneDB")
        if ok and zoneDB and zoneDB.GetAreaIdByName then
            local ok2, id = pcall(zoneDB.GetAreaIdByName, zoneDB, inst.name)
            if ok2 and id then return id end
        end
    end
    return nil
end

-- Every quest for the instance (including ones for the other faction or
-- another class, which the Quests tab marks), and, with a boss, only those
-- involving that boss. nil while the index is built.
function D:QuestsFor(inst, boss)
    if not byArea then
        self:Build()
        return nil
    end
    local area = AreaOf(inst)
    local list = area and byArea[area] or {}
    local out = {}
    for _, questID in ipairs(list) do
        local keep = true
        if boss then
            keep = false
            for _, npc in ipairs(boss.npcIDs or {}) do
                if npcsOf[questID] and npcsOf[questID][npc] then keep = true break end
            end
        end
        if keep then out[#out + 1] = questID end
    end
    return out
end
