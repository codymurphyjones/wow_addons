local _, ns = ...

-- Quest facts, read from QuestieDB (built for this server): titles, chains,
-- who gives each quest, who may take it, and which quests reward gear.
local Q = {}
ns.Quests = Q

local DB = LibQuestieDB
local MAX_CHAIN = 25

-- Item classes that are gear: weapons (2) and armor (4).
local GEAR_CLASS = { [2] = true, [4] = true }

-- Quests seen in game by a dev-mode harvest (Data\Quests.lua): used for
-- quests QuestieDB doesn't have, or fields it leaves out.
local SHIPPED_KEY = { name = "name", questLevel = "level", requiredLevel = "req",
    requiredRaces = "races", requiredClasses = "classes" }

local function Shipped(id)
    local data = ns.ShippedQuests
    return data and data.quests[id]
end

local function Get(id, key)
    local value
    if DB and DB.Quest then
        local ok, v = pcall(DB.Quest.Get, id, key)
        if ok then value = v end
    end
    if value == nil and SHIPPED_KEY[key] then
        local s = Shipped(id)
        value = s and s[SHIPPED_KEY[key]]
    end
    return value
end
Q.Get = Get

function Q:InQuestieDB(id)
    return DB and DB.Quest and DB.Quest.Exists(id) or false
end

function Q:Exists(id)
    return self:InQuestieDB(id) or Shipped(id) ~= nil
end

function Q:Title(id)
    return Get(id, "name") or ("Quest #" .. id)
end

---------------------------------------------------------------------------
-- Completion and eligibility
---------------------------------------------------------------------------

local IsDone = (C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted) or IsQuestFlaggedCompleted

function Q:Done(id)
    return IsDone and IsDone(id) and true or false
end

-- The first NPC (or object) in a startedBy / finishedBy list:
-- { kind = "npc" or "object", id, name, spawns, zoneID, friendly, subName }.
local function Person(list)
    if type(list) ~= "table" then return nil end
    local npc = type(list[1]) == "table" and list[1][1]
    if npc and DB.Npc then
        return {
            kind = "npc", id = npc, name = DB.Npc.Get(npc, "name"), spawns = DB.Npc.Get(npc, "spawns"),
            zoneID = DB.Npc.Get(npc, "zoneID"), friendly = DB.Npc.Get(npc, "friendlyToFaction"),
            level = DB.Npc.Get(npc, "maxLevel"), subName = DB.Npc.Get(npc, "subName"),
        }
    end
    local object = type(list[2]) == "table" and list[2][1]
    if object and DB.Object then
        return {
            kind = "object", id = object, name = DB.Object.Get(object, "name"),
            spawns = DB.Object.Get(object, "spawns"), zoneID = DB.Object.Get(object, "zoneID"),
        }
    end
    return nil
end

-- The giver the harvest saw in game: { kind, id, name, map, x, y }, with
-- the NPC's faction when QuestieDB knows the NPC.
local function ShippedGiver(id)
    local s = Shipped(id)
    local g = s and s.giver
    if not g then return nil end
    local friendly
    if g.kind == "npc" and g.id and DB.Npc then
        local ok, f = pcall(DB.Npc.Get, g.id, "friendlyToFaction")
        if ok then friendly = f end
    end
    return { kind = g.kind or "npc", id = g.id, name = g.name, map = g.map, x = g.x, y = g.y, friendly = friendly }
end

-- Who gives the quest, and who takes it back.
function Q:Giver(id)
    return Person(Get(id, "startedBy")) or ShippedGiver(id)
end

function Q:Ender(id)
    return Person(Get(id, "finishedBy"))
end

-- Is the quest in your quest log right now (accepted, not yet handed in)?
function Q:InLog(id)
    if C_QuestLog and C_QuestLog.GetLogIndexForQuestID then
        local index = C_QuestLog.GetLogIndexForQuestID(id)
        return index ~= nil and index > 0
    end
    if GetQuestLogIndexByID then
        local index = GetQuestLogIndexByID(id)
        return index ~= nil and index > 0
    end
    return false
end

---------------------------------------------------------------------------
-- Steps the giver turned out not to offer
---------------------------------------------------------------------------

-- Saved per character: steps we went to whose giver didn't offer them
-- (already done before the game kept track, or not for this character).
local function Skips()
    -- Saved under the old name (LootPriorityPlugin): carry it over.
    if type(SpyGlassPluginQuestsDB) ~= "table" and type(LootPriorityPluginDB) == "table" then
        SpyGlassPluginQuestsDB = LootPriorityPluginDB
    end
    LootPriorityPluginDB = nil
    SpyGlassPluginQuestsDB = type(SpyGlassPluginQuestsDB) == "table" and SpyGlassPluginQuestsDB or {}
    SpyGlassPluginQuestsDB.skipped = SpyGlassPluginQuestsDB.skipped or {}
    return SpyGlassPluginQuestsDB.skipped
end

function Q:Skipped(id)
    return Skips()[id] and true or false
end

function Q:Skip(id)
    Skips()[id] = true
end

-- Forgets the skips in one chain (the chain leading to reward).
function Q:ResetSkips(reward)
    local skips = Skips()
    for _, id in ipairs(self:Chain(reward)) do skips[id] = nil end
end

-- Race and class masks are tested with plain arithmetic rather than the bit
-- library: QuestieDB's masks carry flag bits above the 32 race/class bits
-- (2^32, 2^33), and a 32-bit bit.band can't be trusted with numbers that size.
local function HasBit(mask, n)
    return math.floor(mask / 2 ^ (n - 1)) % 2 == 1
end

-- Race IDs on each side (1 Human, 3 Dwarf, 4 Night Elf, 7 Gnome; 2 Orc,
-- 5 Undead, 6 Tauren, 8 Troll).
local SIDE_RACES = { Alliance = { 1, 3, 4, 7 }, Horde = { 2, 5, 6, 8 } }

local function AnyBit(mask, ids)
    for _, n in ipairs(ids) do
        if HasBit(mask, n) then return true end
    end
    return false
end

local playerRace, playerClass, playerFaction
local function Player()
    if playerFaction == nil then
        playerRace = select(3, UnitRace("player"))
        playerClass = select(3, UnitClass("player"))
        playerFaction = UnitFactionGroup("player") or false
    end
    return playerRace, playerClass, playerFaction
end

-- Is your race in the mask? Without a race ID from the game, any race of
-- your faction counts, so a missing ID never hides everything.
local function RaceAllowed(races)
    local race, _, faction = Player()
    if race then return HasBit(races, race) end
    local side = faction and SIDE_RACES[faction]
    return not side or AnyBit(races, side)
end

local function Masks(id)
    -- Only the low 32 bits name races and classes.
    return (Get(id, "requiredRaces") or 0) % 4294967296, (Get(id, "requiredClasses") or 0) % 4294967296
end

-- Can your character take this quest (race, class and, when the quest
-- doesn't say, the giver's faction)?
function Q:Allowed(id)
    local _, class, faction = Player()
    local races, classes = Masks(id)
    if races ~= 0 and not RaceAllowed(races) then return false end
    if classes ~= 0 and class and not HasBit(classes, class) then return false end
    if races == 0 then
        local giver = self:Giver(id)
        local friendly = giver and giver.friendly
        if friendly == "A" and faction == "Horde" then return false end
        if friendly == "H" and faction == "Alliance" then return false end
    end
    return true
end

-- Why your character can't take a quest, in a few words ("Horde only",
-- "Warrior only"), or nil when it can.
function Q:WhyNot(id)
    if self:Allowed(id) then return nil end
    local _, class = Player()
    local races, classes = Masks(id)
    if classes ~= 0 and class and not HasBit(classes, class) then
        local names = {}
        for classID = 1, 11 do
            if HasBit(classes, classID) and GetClassInfo then
                local name = GetClassInfo(classID)
                if name then names[#names + 1] = name end
            end
        end
        return (#names > 0 and table.concat(names, ", ") or "Another class") .. " only"
    end
    if races ~= 0 then
        local horde, alliance = AnyBit(races, SIDE_RACES.Horde), AnyBit(races, SIDE_RACES.Alliance)
        if horde and not alliance then return "Horde only" end
        if alliance and not horde then return "Alliance only" end
        return "Other races only"
    end
    local giver = self:Giver(id)
    if giver and giver.friendly == "H" then return "Horde only" end
    if giver and giver.friendly == "A" then return "Alliance only" end
    return "Not for your character"
end

---------------------------------------------------------------------------
-- Chains
---------------------------------------------------------------------------

-- The quest before this one in its chain, or nil.
function Q:Prev(id)
    for _, key in ipairs({ "preQuestSingle", "preQuestGroup" }) do
        local list = Get(id, key)
        if type(list) == "table" then
            -- Prefer a step your character can take (chains split by faction).
            for _, prev in ipairs(list) do
                if self:Exists(prev) and self:Allowed(prev) then return prev end
            end
            for _, prev in ipairs(list) do
                if self:Exists(prev) then return prev end
            end
        end
    end
    return nil
end

local chains = {}
-- { first, ..., id }: the chain leading to this quest, first step first.
function Q:Chain(id)
    local cached = chains[id]
    if cached then return cached end
    local list, seen, cur = { id }, { [id] = true }, id
    while #list < MAX_CHAIN do
        local prev = self:Prev(cur)
        if not prev or seen[prev] then break end
        seen[prev] = true
        table.insert(list, 1, prev)
        cur = prev
    end
    chains[id] = list
    return list
end

-- The first step of the chain you haven't done (and that wasn't skipped
-- because its giver didn't offer it), its place, and the chain. With no
-- completion data at all, that's the first step.
function Q:NextStep(id)
    local chain = self:Chain(id)
    for i, step in ipairs(chain) do
        if not self:Done(step) and (not self:Skipped(step) or step == id or self:InLog(step)) then
            return step, i, chain
        end
    end
    return id, #chain, chain
end

-- Where to go for the next step: { quest, person, action = "pickup" or
-- "turnin" }. A step in your quest log goes to the NPC who takes it back.
function Q:Target(reward)
    local step = self:NextStep(reward)
    if self:InLog(step) then
        local ender = self:Ender(step)
        if ender then return { quest = step, person = ender, action = "turnin" } end
    end
    return { quest = step, person = self:Giver(step), action = "pickup" }
end

---------------------------------------------------------------------------
-- Quests that reward gear
---------------------------------------------------------------------------

Q.rewardsByQuest = {} -- [questID] = { itemID, ... }

-- Goes through QuestieDB's items a few hundred per frame (so logging in
-- doesn't stall) and calls onDone({ { itemID, quest }, ... }) with every
-- weapon or armor reward. Quality (green or better) is checked later from
-- the game's own item info.
-- The item's expected required level, from QuestieDB without asking the
-- server: its required level when set, else roughly its item level less 5.
-- SpyGlass skips items far from your level before asking about them.
local function ItemGet(itemID, key)
    local ok, v = pcall(DB.Item.Get, itemID, key)
    return ok and v or nil
end

local function LevelHint(itemID)
    local req = ItemGet(itemID, "requiredLevel")
    if req and req > 0 then return req end
    local itemLevel = ItemGet(itemID, "itemLevel")
    if itemLevel and itemLevel > 0 then return math.max(1, itemLevel - 5) end
    -- Not in QuestieDB: SpyGlass's shipped item data, if it has the item.
    local info = SpyGlass and SpyGlass:PeekItem(itemID)
    return info and info.fitLevel or nil
end

-- Weapon or armor by QuestieDB's class, or (when QuestieDB has it wrong or
-- not at all) by what the game or SpyGlass's item data says.
local function IsGear(itemID)
    if GEAR_CLASS[ItemGet(itemID, "class") or 0] then return true end
    if not (SpyGlass and SpyGlass.InstantItem) then return false end
    local equipLoc, _, _, classID = SpyGlass:InstantItem(itemID)
    return equipLoc ~= nil and equipLoc ~= "" and GEAR_CLASS[classID or 0] or false
end

function Q:ScanRewards(onDone)
    if not (DB and DB.Item and DB.Item.GetAllIds) then onDone({}) return end
    local ids = DB.Item.GetAllIds()
    local found, seen, index, perFrame = {}, {}, 1, 400
    local function Add(itemID, quest)
        local key = quest .. ":" .. itemID
        if seen[key] then return end
        seen[key] = true
        found[#found + 1] = { itemID = itemID, quest = quest, levelHint = LevelHint(itemID) }
        local list = Q.rewardsByQuest[quest]
        if not list then
            list = {}
            Q.rewardsByQuest[quest] = list
        end
        list[#list + 1] = itemID
    end
    C_Timer.NewTicker(0.01, function(ticker)
        local last = math.min(index + perFrame - 1, #ids)
        for i = index, last do
            local itemID = ids[i]
            local quests = ItemGet(itemID, "questRewards")
            if type(quests) == "table" and IsGear(itemID) then
                for _, quest in ipairs(quests) do Add(itemID, quest) end
            end
        end
        index = last + 1
        if index > #ids then
            ticker:Cancel()
            -- Rewards the harvest saw in game that QuestieDB doesn't list.
            local shipped = ns.ShippedQuests and ns.ShippedQuests.rewards or {}
            for quest, items in pairs(shipped) do
                for _, itemID in ipairs(items) do
                    if IsGear(itemID) then Add(itemID, quest) end
                end
            end
            onDone(found)
        end
    end)
end
