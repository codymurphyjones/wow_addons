local _, ns = ...

-- Where a quest giver stands: continent, zone, subzone and map position.
-- QuestieDB gives spawns as { [areaID] = { { x, y }, ... } } in percent of
-- that zone's map; Questie's ZoneDB (when Questie is loaded) turns area IDs
-- into map IDs and knows which areas are subzones.
local L = {}
ns.Location = L

local zoneDB
local function ZoneDB()
    if zoneDB == nil then
        zoneDB = false
        if QuestieLoader and QuestieLoader.ImportModule then
            local ok, module = pcall(QuestieLoader.ImportModule, QuestieLoader, "ZoneDB")
            if ok and module and module.GetUiMapIdByAreaId then zoneDB = module end
        end
    end
    return zoneDB or nil
end

local function AreaName(areaID)
    return areaID and C_Map.GetAreaInfo and C_Map.GetAreaInfo(areaID) or nil
end

-- Map IDs by name, for when Questie's ZoneDB isn't available.
local byName
local function MapByName(name)
    if not name then return nil end
    if not byName then
        byName = {}
        local ok, children = pcall(C_Map.GetMapChildrenInfo, 946, nil, true) -- the whole world
        if not ok or not children then ok, children = pcall(C_Map.GetMapChildrenInfo, 947, nil, true) end
        for _, info in ipairs(ok and children or {}) do
            if info.name and not byName[info.name] then byName[info.name] = info.mapID end
        end
    end
    return byName[name]
end

local function UiMapID(areaID)
    local db = ZoneDB()
    if db then
        local ok, id = pcall(db.GetUiMapIdByAreaId, db, areaID)
        if ok and id then return id end
    end
    return MapByName(AreaName(areaID))
end

local function ParentZone(areaID)
    local db = ZoneDB()
    if db and db.GetParentZoneId then
        local ok, parent = pcall(db.GetParentZoneId, db, areaID)
        if ok and parent and parent ~= areaID then return parent end
    end
    return nil
end

local CONTINENT = Enum and Enum.UIMapType and Enum.UIMapType.Continent or 2

local function Continent(uiMapID)
    local id, guard = uiMapID, 0
    while id and guard < 10 do
        local info = C_Map.GetMapInfo(id)
        if not info then return nil end
        if info.mapType == CONTINENT then return info.name end
        id, guard = info.parentMapID, guard + 1
    end
    return nil
end

-- { uiMapID, x, y (0-1), continent, zone, subzone, coords = "45.2, 61.8", giver }
-- for a quest's giver, or nil when QuestieDB has no spawn for it.
function L:ForQuest(questID)
    return self:ForPerson(ns.Quests:Giver(questID), questID)
end

-- The same for any NPC or object (from Quests:Giver / Quests:Ender);
-- questID, when given, can name the subzone.
function L:ForPerson(giver, questID)
    local spawns = giver and giver.spawns
    if type(spawns) ~= "table" then
        -- Seen in game by a dev-mode harvest: the map and spot where you stood.
        if not (giver and giver.map and giver.x) then return nil end
        local info = C_Map.GetMapInfo(giver.map)
        return {
            uiMapID = giver.map, x = giver.x, y = giver.y,
            continent = Continent(giver.map), zone = info and info.name,
            coords = string.format("%.1f, %.1f", giver.x * 100, giver.y * 100),
            giver = giver,
        }
    end
    local areaID = giver.zoneID and spawns[giver.zoneID] and giver.zoneID
    if not areaID then
        for id in pairs(spawns) do areaID = id break end
    end
    local point = areaID and spawns[areaID] and spawns[areaID][1]
    if not point then return nil end
    -- Inside a dungeon or raid: QuestieDB has no map position (-1, -1).
    if (point[1] or 0) < 0 then
        return { inside = true, zone = AreaName(areaID), coords = "inside the instance", giver = giver, areaID = areaID }
    end

    -- A spawn listed under a subzone belongs on its parent zone's map.
    local zoneArea, subzoneArea = areaID, nil
    local parent = ParentZone(areaID)
    if parent then
        zoneArea, subzoneArea = parent, areaID
    else
        -- Otherwise the quest's own area may name the subzone (Goldshire in Elwynn).
        local questArea = questID and ns.Quests.Get(questID, "zoneOrSort") or 0
        if questArea > 0 and ParentZone(questArea) == areaID then subzoneArea = questArea end
    end

    local uiMapID = UiMapID(areaID) or UiMapID(zoneArea)
    local x, y = (point[1] or 0) / 100, (point[2] or 0) / 100
    return {
        uiMapID = uiMapID, x = x, y = y,
        continent = uiMapID and Continent(uiMapID),
        zone = AreaName(zoneArea) or (uiMapID and C_Map.GetMapInfo(uiMapID) and C_Map.GetMapInfo(uiMapID).name),
        subzone = subzoneArea and AreaName(subzoneArea) or nil,
        coords = string.format("%.1f, %.1f", point[1] or 0, point[2] or 0),
        giver = giver,
    }
end
