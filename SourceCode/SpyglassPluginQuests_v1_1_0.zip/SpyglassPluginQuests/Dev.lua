local _, ns = ...

-- Developer tool, only in SpyGlass's dev mode (D.DEV_MODE in Spyglass\Data.lua).
--   /sg harvest quests start: goes through every QuestieDB quest reward and
--     hands the items to SpyGlass's /sg harvest, which saves their details
--     from the server (so rewards QuestieDB has the wrong item class for are
--     found).
--   Always on in dev mode: every quest you see in game (offered, accepted,
--     handed in, or in your log) is recorded with its rewards, giver and
--     where you stood. This finds quests QuestieDB doesn't know about.
-- Saved in SpyGlassPluginQuestsDevDB; Spyglass\Tools\build_items.py turns it
-- into Data\Quests.lua.
if not (SpyGlass and SpyGlass.IsDevMode and SpyGlass:IsDevMode() and LibQuestieDB) then return end

local DB = LibQuestieDB
local Q = ns.Quests
local PREFIX = "|TInterface\\AddOns\\Spyglass\\Media\\Icon:14:14|t |cff66bbffSpyGlass quest harvest|r: "

-- SpyGlassPluginQuestsDevDB = {
--   rewards = { [questID] = { itemID, ... } },  -- QuestieDB's questRewards (every item class)
--   itemClass = { [itemID] = QuestieDB class or 0 },
--   quests = { [questID] = { name, questLevel, requiredLevel, giver } }, -- QuestieDB, rewarding quests only
--   captured = { [questID] = { name, level, giver = { kind, id, name, map, x, y },
--                ender = { ... }, rewards = { itemID, ... }, choices = { ... },
--                factions = { Alliance = true }, new = true when QuestieDB lacks it } },
--   swept = time of the last full sweep,
-- }
local db

local function Init()
    SpyGlassPluginQuestsDevDB = type(SpyGlassPluginQuestsDevDB) == "table" and SpyGlassPluginQuestsDevDB or {}
    db = SpyGlassPluginQuestsDevDB
    db.version = 1
    for _, k in ipairs({ "rewards", "itemClass", "quests", "captured" }) do
        db[k] = type(db[k]) == "table" and db[k] or {}
    end
end
Init()

local function Count(t)
    local n = 0
    for _ in pairs(t) do n = n + 1 end
    return n
end

local function Safe(entity, id, key)
    local ok, v = pcall(entity.Get, id, key)
    return ok and v or nil
end

---------------------------------------------------------------------------
-- QuestieDB sweep
---------------------------------------------------------------------------

local sweeping

local function Sweep()
    if sweeping then print(PREFIX .. "already sweeping.") return end
    if not (DB.Item and DB.Item.GetAllIds) then print(PREFIX .. "QuestieDB has no item list.") return end
    sweeping = true
    local ids = DB.Item.GetAllIds()
    local index, perFrame, items = 1, 400, {}
    print(PREFIX .. "sweeping " .. #ids .. " QuestieDB items for quest rewards...")
    C_Timer.NewTicker(0.01, function(ticker)
        local last = math.min(index + perFrame - 1, #ids)
        for i = index, last do
            local itemID = ids[i]
            local quests = Safe(DB.Item, itemID, "questRewards")
            if type(quests) == "table" and #quests > 0 then
                db.itemClass[itemID] = Safe(DB.Item, itemID, "class") or 0
                items[#items + 1] = itemID
                for _, quest in ipairs(quests) do
                    local list = db.rewards[quest] or {}
                    db.rewards[quest] = list
                    if not tContains(list, itemID) then list[#list + 1] = itemID end
                    if not db.quests[quest] then
                        local startedBy = Safe(DB.Quest, quest, "startedBy")
                        local npc = type(startedBy) == "table" and type(startedBy[1]) == "table" and startedBy[1][1]
                        db.quests[quest] = {
                            name = Safe(DB.Quest, quest, "name"), questLevel = Safe(DB.Quest, quest, "questLevel"),
                            requiredLevel = Safe(DB.Quest, quest, "requiredLevel"), giver = npc or nil,
                        }
                    end
                end
            end
        end
        index = last + 1
        if index > #ids then
            ticker:Cancel()
            sweeping = false
            db.swept = time()
            local added = SpyGlass:HarvestItems(items)
            print(PREFIX .. string.format("sweep done: %d reward items in %d quests; %d new to the item harvest.",
                #items, Count(db.rewards), added))
        end
    end)
end

---------------------------------------------------------------------------
-- Live capture
---------------------------------------------------------------------------

local function ItemID(link)
    return link and tonumber(link:match("item:(%d+)"))
end

-- Where you stand: map ID and x, y (0-1).
local function Here()
    local map = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
    if not map then return nil end
    local pos = C_Map.GetPlayerMapPosition(map, "player")
    local x, y = pos and pos:GetXY()
    return map, x, y
end

-- The NPC (or object) you're talking to.
local function Npc()
    local guid = UnitGUID("npc")
    if not guid then return nil end
    local kind, _, _, _, _, id = strsplit("-", guid)
    if kind ~= "Creature" and kind ~= "GameObject" then return nil end
    local map, x, y = Here()
    return { kind = kind == "Creature" and "npc" or "object", id = tonumber(id), name = UnitName("npc"), map = map, x = x, y = y }
end

local function Union(list, ids)
    local added = 0
    for _, id in ipairs(ids) do
        if not tContains(list, id) then
            list[#list + 1] = id
            added = added + 1
        end
    end
    return added
end

-- Records what we learned about a quest. info: { name, level, giver, ender,
-- rewards = { ids }, choices = { ids } }.
local function Capture(questID, info)
    if not questID or questID == 0 then return end
    local c = db.captured[questID]
    local isNew = c == nil
    c = c or { rewards = {}, choices = {}, factions = {} }
    db.captured[questID] = c
    c.name = info.name or c.name
    c.level = (info.level and info.level > 0) and info.level or c.level
    c.giver = info.giver or c.giver
    c.ender = info.ender or c.ender
    c.new = not Q:InQuestieDB(questID) or nil
    c.factions[UnitFactionGroup("player") or "?"] = true
    local added = Union(c.rewards, info.rewards or {}) + Union(c.choices, info.choices or {})
    if added > 0 then
        local ids = {}
        for _, id in ipairs(c.rewards) do ids[#ids + 1] = id end
        for _, id in ipairs(c.choices) do ids[#ids + 1] = id end
        SpyGlass:HarvestItems(ids)
    end
    if isNew or added > 0 then
        print(PREFIX .. string.format("%s [%d]%s: %d reward, %d choice item(s).", c.name or "?", questID,
            c.new and " |cffff8040(not in QuestieDB)|r" or "", #c.rewards, #c.choices))
    end
end

-- The quest frame (offer or hand-in) that's open now.
local function FromQuestFrame(isComplete)
    local info = { name = GetTitleText and GetTitleText(), rewards = {}, choices = {} }
    for i = 1, (GetNumQuestRewards and GetNumQuestRewards() or 0) do
        info.rewards[#info.rewards + 1] = ItemID(GetQuestItemLink("reward", i))
    end
    for i = 1, (GetNumQuestChoices and GetNumQuestChoices() or 0) do
        info.choices[#info.choices + 1] = ItemID(GetQuestItemLink("choice", i))
    end
    if isComplete then info.ender = Npc() else info.giver = Npc() end
    Capture(GetQuestID and GetQuestID(), info)
end

-- One quest log entry (selecting it briefly, then putting the selection back).
local function FromLog(index)
    local title, level, _, isHeader, _, _, _, questID = GetQuestLogTitle(index)
    if isHeader or not questID then return end
    local before = GetQuestLogSelection and GetQuestLogSelection()
    SelectQuestLogEntry(index)
    local info = { name = title, level = level, rewards = {}, choices = {} }
    for i = 1, (GetNumQuestLogRewards and GetNumQuestLogRewards() or 0) do
        info.rewards[#info.rewards + 1] = ItemID(GetQuestLogItemLink("reward", i))
    end
    for i = 1, (GetNumQuestLogChoices and GetNumQuestLogChoices() or 0) do
        info.choices[#info.choices + 1] = ItemID(GetQuestLogItemLink("choice", i))
    end
    if before and before > 0 then SelectQuestLogEntry(before) end
    Capture(questID, info)
end

local function ScanLog()
    if not GetNumQuestLogEntries then return end
    for index = 1, (GetNumQuestLogEntries()) do pcall(FromLog, index) end
end

local events = CreateFrame("Frame")
for _, event in ipairs({ "QUEST_DETAIL", "QUEST_COMPLETE", "QUEST_ACCEPTED" }) do
    pcall(events.RegisterEvent, events, event)
end
events:SetScript("OnEvent", function(_, event)
    if event == "QUEST_ACCEPTED" then
        -- The log has the quest's level; it updates a moment after.
        C_Timer.After(0.5, ScanLog)
    else
        pcall(FromQuestFrame, event == "QUEST_COMPLETE")
    end
end)
C_Timer.After(3, ScanLog)

---------------------------------------------------------------------------
-- /sg harvest quests ...
---------------------------------------------------------------------------

SpyGlass:RegisterHarvestCommand("quests", function(arg)
    arg = strtrim(arg or "")
    if arg == "start" then
        Sweep()
    elseif arg == "reset" then
        SpyGlassPluginQuestsDevDB = nil
        Init()
        print(PREFIX .. "quest harvest data cleared.")
    else
        local new = 0
        for _, c in pairs(db.captured) do if c.new then new = new + 1 end end
        print(PREFIX .. string.format("QuestieDB sweep: %s, %d quests with rewards. Captured in game: %d quests (%d not in QuestieDB).",
            db.swept and date("%Y-%m-%d %H:%M", db.swept) or "not run", Count(db.rewards), Count(db.captured), new))
        print("  /sg harvest quests start | status | reset   (item details: /sg harvest status)")
    end
end)

-- /sg harvest sources: hands the source index's items that SpyGlass's item
-- data lacks (Data\SourcesHarvest.lua) to /sg harvest.
SpyGlass:RegisterHarvestCommand("sources", function()
    local added = SpyGlass:HarvestItems(ns.SourcesHarvest or {})
    print(PREFIX .. string.format("%d source items, %d new to the item harvest.", #(ns.SourcesHarvest or {}), added))
end)

print(PREFIX .. "recording quests you see. /sg harvest quests start sweeps QuestieDB.")
