local _, ns = ...

-- Pictures for the instance tiles, from the game's own files only: the
-- Dungeon Finder backgrounds where the game has one for the place, else a
-- tinted generic card with the first boss's portrait on it.
local Art = {}
ns.Art = Art

local LFG = "Interface\\LFGFrame\\UI-LFG-BACKGROUND-"
local GENERIC = LFG .. "RANDOMDUNGEON"

-- AtlasLoot instance key -> Dungeon Finder picture names to try, in order.
local KEY_TO_LFG = {
    Ragefire = { "RAGEFIRECHASM" },
    WailingCaverns = { "WAILINGCAVERNS" },
    TheDeadmines = { "DEADMINES" },
    ShadowfangKeep = { "SHADOWFANGKEEP" },
    BlackfathomDeeps = { "BLACKFATHOMDEEPS" },
    TheStockade = { "STORMWINDSTOCKADES", "STOCKADES" },
    Gnomeregan = { "GNOMEREGAN" },
    RazorfenKraul = { "RAZORFENKRAUL" },
    ScarletMonasteryGraveyard = { "SCARLETMONASTERYGRAVEYARD", "SCARLETMONASTERY" },
    ScarletMonasteryLibrary = { "SCARLETMONASTERYLIBRARY", "SCARLETMONASTERY" },
    ScarletMonasteryArmory = { "SCARLETMONASTERYARMORY", "SCARLETMONASTERY" },
    ScarletMonasteryCathedral = { "SCARLETMONASTERYCATHEDRAL", "SCARLETMONASTERY" },
    RazorfenDowns = { "RAZORFENDOWNS" },
    Uldaman = { "ULDAMAN" },
    ["Zul'Farrak"] = { "ZULFARAK", "ZULFARRAK" },
    Maraudon = { "MARAUDON" },
    ["TheTempleOfAtal'Hakkar"] = { "SUNKENTEMPLE", "TEMPLEOFATALHAKKAR" },
    BlackrockDepths = { "BLACKROCKDEPTHS" },
    LowerBlackrockSpire = { "LOWERBLACKROCKSPIRE", "BLACKROCKSPIRE" },
    UpperBlackrockSpire = { "UPPERBLACKROCKSPIRE", "BLACKROCKSPIRE" },
    DireMaulEast = { "DIREMAULEAST", "DIREMAUL" },
    DireMaulWest = { "DIREMAULWEST", "DIREMAUL" },
    DireMaulNorth = { "DIREMAULNORTH", "DIREMAUL" },
    Scholomance = { "SCHOLOMANCE" },
    Stratholme = { "STRATHOLME" },
    MoltenCore = { "MOLTENCORE" },
    Onyxia = { "ONYXIASLAIR", "ONYXIA" },
    BlackwingLair = { "BLACKWINGLAIR" },
    ["Zul'Gurub"] = { "ZULGURUB" },
    TheRuinsofAhnQiraj = { "AHNQIRAJRUINS", "RUINSOFAHNQIRAJ", "AQRUINS" },
    TheTempleofAhnQiraj = { "AHNQIRAJTEMPLE", "TEMPLEOFAHNQIRAJ", "AQTEMPLE" },
    Naxxramas = { "NAXXRAMAS" },
}

-- A gentle hue per instance so generic cards don't all look alike. The
-- server's own instances lean blue-violet, the rest warm.
local function Hue(inst)
    local n = 0
    for i = 1, #inst.key do n = (n * 31 + inst.key:byte(i)) % 997 end
    local t = (n % 100) / 100
    if inst.isCustom then
        return 0.45 + 0.25 * t, 0.5 + 0.2 * (1 - t), 0.95
    end
    return 0.95, 0.65 + 0.25 * t, 0.45 + 0.2 * (1 - t)
end

local cache = {} -- [key] = { texture, generic, r, g, b, displayID }

-- What to draw on an instance's tile:
-- { texture, generic = bool, r, g, b, displayID }. probe is any texture
-- region, used to test whether a picture exists (SetTexture answers false
-- when it doesn't).
function Art:For(inst, probe)
    local art = cache[inst.key]
    if art then return art end
    for _, name in ipairs(KEY_TO_LFG[inst.key] or {}) do
        if probe:SetTexture(LFG .. name) then
            art = { texture = LFG .. name, r = 1, g = 1, b = 1 }
            break
        end
    end
    if not art then
        local r, g, b = Hue(inst)
        local displayID
        for _, boss in ipairs(inst.bosses) do
            if boss.displayID then displayID = boss.displayID break end
        end
        art = { texture = GENERIC, generic = true, r = r, g = g, b = b, displayID = displayID }
    end
    cache[inst.key] = art
    return art
end
