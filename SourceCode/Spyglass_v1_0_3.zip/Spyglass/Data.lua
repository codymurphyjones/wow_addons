local _, ns = ...

-- Constants: the level window, equip slots and how item stats map to
-- StatLedger's stat keys.
local D = {}
ns.Data = D

-- Items are shown when their required level is within this window around
-- the player's level. Class-specific items (class restricted, relics, or
-- effects that name one of your class's spells) reach further down.
D.LEVELS_ABOVE = 4
D.LEVELS_BELOW = 12
D.CLASS_LEVELS_BELOW = 20

-- The AtlasLoot module the dungeon and raid loot comes from.
D.ATLAS_MODULE = "AtlasLootClassic_DungeonsAndRaids"

-- Developer mode. Set to true by hand (and /reload) to get /sg harvest,
-- which slowly asks the server about every item and saves what it learns
-- in SpyGlassDevDB. Tools\build_items.py turns that into Data\Items.lua.
-- Leave false in released copies.
D.DEV_MODE = false

-- Item ID ranges /sg harvest walks: Classic's own items, and the Forever
-- server's custom ones. Within PROBE ranges, IDs the client knows nothing
-- about are still asked for (once): custom items often aren't in the
-- client's data until the server sends them.
D.HARVEST_RANGES = {
    { 1, 25000 },
    { 270000, 290000, probe = true },
}
-- Server requests per second while harvesting.
D.HARVEST_RATE = 4

-- Slot groups, in the order the slot dropdown lists them.
D.SLOT_GROUPS = {
    { "ALL", ALL or "All slots" },
    { "HEAD", INVTYPE_HEAD or "Head" },
    { "NECK", INVTYPE_NECK or "Neck" },
    { "SHOULDER", INVTYPE_SHOULDER or "Shoulder" },
    { "BACK", INVTYPE_CLOAK or "Back" },
    { "CHEST", INVTYPE_CHEST or "Chest" },
    { "WRIST", INVTYPE_WRIST or "Wrist" },
    { "HANDS", INVTYPE_HAND or "Hands" },
    { "WAIST", INVTYPE_WAIST or "Waist" },
    { "LEGS", INVTYPE_LEGS or "Legs" },
    { "FEET", INVTYPE_FEET or "Feet" },
    { "FINGER", INVTYPE_FINGER or "Finger" },
    { "TRINKET", INVTYPE_TRINKET or "Trinket" },
    { "MAINHAND", "Weapons" },
    { "OFFHAND", INVTYPE_WEAPONOFFHAND or "Off Hand" },
    { "RANGED", (INVTYPE_RANGED or "Ranged") .. " / " .. (INVTYPE_RELIC or "Relic") },
}

-- Equip location -> slot group. Equip locations not listed (shirts, tabards,
-- bags, ammo) are not gear and are left out of the list.
D.EQUIP_GROUP = {
    INVTYPE_HEAD = "HEAD",
    INVTYPE_NECK = "NECK",
    INVTYPE_SHOULDER = "SHOULDER",
    INVTYPE_CLOAK = "BACK",
    INVTYPE_CHEST = "CHEST",
    INVTYPE_ROBE = "CHEST",
    INVTYPE_WRIST = "WRIST",
    INVTYPE_HAND = "HANDS",
    INVTYPE_WAIST = "WAIST",
    INVTYPE_LEGS = "LEGS",
    INVTYPE_FEET = "FEET",
    INVTYPE_FINGER = "FINGER",
    INVTYPE_TRINKET = "TRINKET",
    INVTYPE_WEAPON = "MAINHAND",
    INVTYPE_2HWEAPON = "MAINHAND",
    INVTYPE_WEAPONMAINHAND = "MAINHAND",
    INVTYPE_WEAPONOFFHAND = "OFFHAND",
    INVTYPE_SHIELD = "OFFHAND",
    INVTYPE_HOLDABLE = "OFFHAND",
    INVTYPE_RANGED = "RANGED",
    INVTYPE_RANGEDRIGHT = "RANGED",
    INVTYPE_THROWN = "RANGED",
    INVTYPE_RELIC = "RANGED",
}

-- GetItemStats keys -> StatLedger stat keys.
D.STAT_ALIASES = {
    ITEM_MOD_STRENGTH_SHORT = "STR",
    ITEM_MOD_AGILITY_SHORT = "AGI",
    ITEM_MOD_STAMINA_SHORT = "STA",
    ITEM_MOD_INTELLECT_SHORT = "INT",
    ITEM_MOD_SPIRIT_SHORT = "SPI",
    ITEM_MOD_ATTACK_POWER_SHORT = "AP",
    ITEM_MOD_ATTACK_POWER = "AP",
    ITEM_MOD_RANGED_ATTACK_POWER_SHORT = "RAP",
    ITEM_MOD_RANGED_ATTACK_POWER = "RAP",
    ITEM_MOD_SPELL_POWER_SHORT = "SP",
    ITEM_MOD_SPELL_POWER = "SP",
    ITEM_MOD_SPELL_DAMAGE_DONE_SHORT = "SP",
    ITEM_MOD_SPELL_DAMAGE_DONE = "SP",
    ITEM_MOD_HEALING_DONE_SHORT = "HEAL",
    ITEM_MOD_HEALING_DONE = "HEAL",
    ITEM_MOD_SPELL_HEALING_DONE_SHORT = "HEAL",
    ITEM_MOD_SPELL_HEALING_DONE = "HEAL",
    ITEM_MOD_CRIT_RATING_SHORT = "CRIT",
    ITEM_MOD_CRIT_MELEE_RATING_SHORT = "CRIT",
    ITEM_MOD_CRIT_RANGED_RATING_SHORT = "CRIT",
    ITEM_MOD_CRIT_SPELL_RATING_SHORT = "SPELLCRIT",
    ITEM_MOD_HIT_RATING_SHORT = "HIT",
    ITEM_MOD_HIT_MELEE_RATING_SHORT = "HIT",
    ITEM_MOD_HIT_RANGED_RATING_SHORT = "HIT",
    ITEM_MOD_HIT_SPELL_RATING_SHORT = "HIT",
    ITEM_MOD_HASTE_RATING_SHORT = "HASTE",
    ITEM_MOD_MANA_REGENERATION_SHORT = "MP5",
    ITEM_MOD_MANA_REGENERATION = "MP5",
    ITEM_MOD_POWER_REGEN0_SHORT = "MP5",
    ITEM_MOD_DEFENSE_SKILL_RATING_SHORT = "DEF",
    ITEM_MOD_DEFENSE_SKILL_RATING = "DEF",
    ITEM_MOD_DODGE_RATING_SHORT = "DODGE",
    ITEM_MOD_PARRY_RATING_SHORT = "PARRY",
    ITEM_MOD_BLOCK_RATING_SHORT = "BLOCK",
    ITEM_MOD_BLOCK_VALUE_SHORT = "BLOCKVALUE",
    ITEM_MOD_BLOCK_VALUE = "BLOCKVALUE",
    RESISTANCE0_NAME = "ARMOR",
    ITEM_MOD_DAMAGE_PER_SECOND_SHORT = "DPS",
}

-- "Equip:" effects that GetItemStats may not report, matched against the
-- lower-cased line (enUS). The first pattern that matches a line wins, so
-- the more specific ones come first. A stat of "SCHOOL" takes the school
-- from the first capture and the amount from the second.
D.EQUIP_PATTERNS = {
    { "damage and healing done by magical spells and effects by up to (%d+)", { "SP", "HEAL" } },
    { "healing done by spells and effects by up to (%d+)", { "HEAL" } },
    { "damage done by (%a+) spells and effects by up to (%d+)", "SCHOOL" },
    { "critical strike with spells by (%d+)", { "SPELLCRIT" } },
    { "critical strike by (%d+)", { "CRIT" } },
    { "chance to hit with spells by (%d+)", { "HIT" } },
    { "chance to hit by (%d+)", { "HIT" } },
    { "restores (%d+) mana per 5 sec", { "MP5" } },
    { "(%d+) mana every 5 sec", { "MP5" } },
    { "%+(%d+) ranged attack power", { "RAP" } },
    { "%+(%d+) attack power", { "AP" } },
    { "increased defense %+(%d+)", { "DEF" } },
    { "chance to dodge an attack by (%d+)", { "DODGE" } },
    { "chance to parry an attack by (%d+)", { "PARRY" } },
    { "chance to block attacks with a shield by (%d+)", { "BLOCK" } },
    { "block value of your shield by (%d+)", { "BLOCKVALUE" } },
    { "attack speed by (%d+)", { "HASTE" } },
}

D.SCHOOLS = { fire = "FIRE", frost = "FROST", shadow = "SHADOW", arcane = "ARCANE", nature = "NATURE" }

-- How much one point (or one percent) of a stat is worth next to one point
-- of a primary stat, roughly by vanilla item budgets. Without this, 1% crit
-- would count the same as 1 Strength.
D.STAT_UNIT = {
    STR = 1, AGI = 1, STA = 1, INT = 1, SPI = 1,
    AP = 0.5, RAP = 0.4, SP = 0.85, HEAL = 0.45,
    FIRE = 0.7, FROST = 0.7, SHADOW = 0.7, ARCANE = 0.7, NATURE = 0.7,
    CRIT = 14, SPELLCRIT = 14, HIT = 10, HASTE = 10, MP5 = 2.5,
    ARMOR = 0.02, DEF = 1.2, DODGE = 12, PARRY = 12, BLOCK = 5, BLOCKVALUE = 0.3,
    DPS = 3,
}

-- Used when StatLedger is not installed.
D.FALLBACK_WEIGHTS = { STA = 0.6, STR = 0.5, AGI = 0.5, INT = 0.5, SPI = 0.3 }

-- What each class can learn to wear and wield in Classic, by item subclass:
-- armor (class 4): 1 cloth, 2 leather, 3 mail, 4 plate, 6 shield, 7 libram,
-- 8 idol, 9 totem; weapons (class 2): 0/1 axe, 2 bow, 3 gun, 4/5 mace,
-- 6 polearm, 7/8 sword, 10 staff, 13 fist, 15 dagger, 16 thrown,
-- 18 crossbow, 19 wand. Miscellaneous armor (rings, necks, trinkets, cloaks)
-- and miscellaneous weapons fit everyone. Used for items not loaded yet,
-- since it needs nothing from the server.
local function Set(...)
    local s = {}
    for i = 1, select("#", ...) do s[select(i, ...)] = true end
    return s
end
D.CLASS_PROFICIENCY = {
    WARRIOR = { armor = Set(1, 2, 3, 4, 6), weapon = Set(0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 13, 15, 16, 18) },
    PALADIN = { armor = Set(1, 2, 3, 4, 6, 7), weapon = Set(0, 1, 4, 5, 6, 7, 8) },
    HUNTER = { armor = Set(1, 2, 3), weapon = Set(0, 1, 2, 3, 6, 7, 8, 10, 13, 15, 16, 18) },
    ROGUE = { armor = Set(1, 2), weapon = Set(2, 3, 4, 7, 13, 15, 16, 18) },
    PRIEST = { armor = Set(1), weapon = Set(4, 10, 15, 19) },
    SHAMAN = { armor = Set(1, 2, 3, 6, 9), weapon = Set(0, 1, 4, 5, 10, 13, 15) },
    MAGE = { armor = Set(1), weapon = Set(7, 10, 15, 19) },
    WARLOCK = { armor = Set(1), weapon = Set(7, 10, 15, 19) },
    DRUID = { armor = Set(1, 2, 8), weapon = Set(4, 5, 10, 13, 15) },
}

-- Class spells too generic to mark an item as class-specific.
D.SPELL_STOPLIST = {
    ["Attack"] = true, ["Auto Shot"] = true, ["Shoot"] = true, ["Throw"] = true,
    ["Parry"] = true, ["Dodge"] = true, ["Block"] = true,
}
