local _, ns = ...

-- The home page: a grid of instance tiles for the selected tab, by level.
-- Instances AtlasLoot lists without any loot yet get a "coming soon" tile.
local Home = {}
ns.Home = Home

local J = ns.J
local COLUMNS = 4
local TILE_W, TILE_H, GAP = 200, 108, 12
local ROW_H = TILE_H + GAP
local CLOCK = "Interface\\Icons\\INV_Misc_PocketWatch_01"

local page

---------------------------------------------------------------------------
-- Tiles
---------------------------------------------------------------------------

local function Edge(tile, layer)
    local edges = {}
    for i = 1, 4 do edges[i] = tile:CreateTexture(nil, layer) end
    edges[1]:SetPoint("TOPLEFT") edges[1]:SetPoint("TOPRIGHT") edges[1]:SetHeight(1)
    edges[2]:SetPoint("BOTTOMLEFT") edges[2]:SetPoint("BOTTOMRIGHT") edges[2]:SetHeight(1)
    edges[3]:SetPoint("TOPLEFT") edges[3]:SetPoint("BOTTOMLEFT") edges[3]:SetWidth(1)
    edges[4]:SetPoint("TOPRIGHT") edges[4]:SetPoint("BOTTOMRIGHT") edges[4]:SetWidth(1)
    return edges
end

local function SetEdgeColor(edges, r, g, b, a)
    for _, edge in ipairs(edges) do edge:SetColorTexture(r, g, b, a) end
end

local function TileTooltip(tile)
    local inst = tile.inst
    GameTooltip:SetOwner(tile, "ANCHOR_RIGHT")
    GameTooltip:SetText(inst.name, 1, 0.82, 0)
    GameTooltip:AddLine("Levels " .. J.LevelText(inst), 1, 1, 1)
    if inst.comingSoon then
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Loot coming soon", 1, 0.82, 0)
        GameTooltip:AddLine("AtlasLoot lists this place, but its loot hasn't been data-mined yet. "
            .. "It will show here once AtlasLoot is updated.", 0.8, 0.8, 0.8, true)
    else
        GameTooltip:AddLine(#inst.bosses .. " bosses, " .. #inst.items .. " pieces of gear", 0.8, 0.8, 0.8)
    end
    if inst.isCustom then GameTooltip:AddLine("Added by this server", 0.4, 0.8, 1) end
    GameTooltip:Show()
end

local function CreateTile(parent)
    local tile = CreateFrame("Button", nil, parent)
    tile:SetSize(TILE_W, TILE_H)

    tile.art = tile:CreateTexture(nil, "BACKGROUND")
    tile.art:SetPoint("TOPLEFT", 1, -1)
    tile.art:SetPoint("BOTTOMRIGHT", -1, 1)
    tile.lift = tile:CreateTexture(nil, "BACKGROUND", nil, 1)
    tile.lift:SetAllPoints(tile.art)
    tile.lift:SetBlendMode("ADD")
    tile.lift:SetAlpha(0.25)
    tile.lift:Hide()

    -- Boss portrait medallion on generic cards.
    tile.portrait = tile:CreateTexture(nil, "BORDER")
    tile.portrait:SetSize(54, 54)
    tile.portrait:SetPoint("CENTER", 0, -4)
    local mask = tile:CreateMaskTexture()
    mask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    mask:SetAllPoints(tile.portrait)
    tile.portrait:AddMaskTexture(mask)

    tile.scrimTop = tile:CreateTexture(nil, "ARTWORK")
    tile.scrimTop:SetPoint("TOPLEFT", tile.art)
    tile.scrimTop:SetPoint("TOPRIGHT", tile.art)
    tile.scrimTop:SetHeight(52)
    J.Fade(tile.scrimTop, 0, 0.85)
    tile.scrimBottom = tile:CreateTexture(nil, "ARTWORK")
    tile.scrimBottom:SetPoint("BOTTOMLEFT", tile.art)
    tile.scrimBottom:SetPoint("BOTTOMRIGHT", tile.art)
    tile.scrimBottom:SetHeight(30)
    J.Fade(tile.scrimBottom, 0.9, 0)

    tile.title = J.TitleText(tile, 17)
    tile.title:SetPoint("TOP", 0, -7)
    tile.title:SetWidth(TILE_W - 16)
    tile.title:SetJustifyH("CENTER")
    tile.title:SetTextColor(1, 0.92, 0.75)
    if tile.title.SetMaxLines then tile.title:SetMaxLines(2) end

    tile.range = tile:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    tile.range:SetPoint("BOTTOMLEFT", 8, 6)
    tile.count = tile:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    tile.count:SetPoint("BOTTOMRIGHT", -8, 6)
    tile.tag = tile:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    tile.tag:SetPoint("BOTTOM", 0, 6)
    tile.tag:SetTextColor(0.4, 0.8, 1)
    tile.tag:SetText("Forever")

    -- "Loot coming soon" band across the lower middle.
    local band = CreateFrame("Frame", nil, tile)
    band:SetPoint("LEFT", 1, -14)
    band:SetPoint("RIGHT", -1, -14)
    band:SetHeight(24)
    local bandBg = band:CreateTexture(nil, "BACKGROUND")
    bandBg:SetAllPoints()
    bandBg:SetColorTexture(0.05, 0.04, 0.02, 0.85)
    local top = band:CreateTexture(nil, "BORDER")
    top:SetPoint("TOPLEFT") top:SetPoint("TOPRIGHT") top:SetHeight(1)
    top:SetColorTexture(1, 0.78, 0.25, 0.9)
    local bottom = band:CreateTexture(nil, "BORDER")
    bottom:SetPoint("BOTTOMLEFT") bottom:SetPoint("BOTTOMRIGHT") bottom:SetHeight(1)
    bottom:SetColorTexture(1, 0.78, 0.25, 0.9)
    band.text = band:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    band.text:SetPoint("CENTER", 9, 0)
    band.text:SetText("LOOT COMING SOON")
    band.text:SetTextColor(1, 0.82, 0.3)
    local clock = band:CreateTexture(nil, "ARTWORK")
    clock:SetSize(16, 16)
    clock:SetPoint("RIGHT", band.text, "LEFT", -4, 0)
    clock:SetTexture(CLOCK)
    clock:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    tile.band = band

    tile.edges = Edge(tile, "OVERLAY")
    SetEdgeColor(tile.edges, 0, 0, 0, 0.9)

    tile:SetScript("OnEnter", function(self)
        self.lift:Show()
        SetEdgeColor(self.edges, 1, 0.82, 0.2, 1)
        TileTooltip(self)
    end)
    tile:SetScript("OnLeave", function(self)
        self.lift:Hide()
        SetEdgeColor(self.edges, 0, 0, 0, 0.9)
        GameTooltip:Hide()
    end)
    tile:SetScript("OnClick", function(self)
        PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON or 856)
        J:ShowInstance(self.inst.key, 0)
    end)
    return tile
end

local function SetupTile(tile, inst)
    tile.inst = inst
    local art = ns.Art:For(inst, tile.art)
    tile.art:SetTexture(art.texture)
    tile.art:SetTexCoord(0.04, 0.96, 0.08, 0.92) -- the pictures are wider than the tile
    tile.lift:SetTexture(art.texture)
    tile.lift:SetTexCoord(0.04, 0.96, 0.08, 0.92)
    local soon = inst.comingSoon
    tile.art:SetDesaturated(soon)
    local dim = soon and 0.5 or 1
    tile.art:SetVertexColor(art.r * dim, art.g * dim, art.b * dim)

    if art.generic and art.displayID and SetPortraitTextureFromCreatureDisplayID then
        SetPortraitTextureFromCreatureDisplayID(tile.portrait, art.displayID)
        tile.portrait:SetDesaturated(soon)
        tile.portrait:SetAlpha(soon and 0.5 or 0.9)
        tile.portrait:Show()
    else
        tile.portrait:Hide()
    end

    tile.title:SetText(inst.name)
    tile.range:SetText(J.LevelText(inst))
    if soon then
        tile.count:SetText("|cff999999Not yet recorded|r")
    else
        tile.count:SetText(#inst.bosses .. (#inst.bosses == 1 and " boss" or " bosses"))
    end
    tile.band:SetShown(soon)
    tile.tag:SetShown(inst.isCustom and not soon)
end

local function InitRow(row, data)
    if not row.tiles then
        row.tiles = {}
        for i = 1, COLUMNS do
            local tile = CreateTile(row)
            tile:SetPoint("TOPLEFT", (i - 1) * (TILE_W + GAP), 0)
            row.tiles[i] = tile
        end
    end
    for i, tile in ipairs(row.tiles) do
        local inst = data[i]
        tile:SetShown(inst ~= nil)
        if inst then SetupTile(tile, inst) end
    end
end

---------------------------------------------------------------------------
-- Filtering
---------------------------------------------------------------------------

local function InBand(inst)
    local band = J.db.band
    if band == "ALL" then return true end
    local lo, hi
    if band == "MINE" then
        local level = UnitLevel("player")
        lo, hi = level - 8, level + 4
    else
        for _, option in ipairs(J.BANDS) do
            if option[1] == band then lo, hi = option[3], option[4] end
        end
    end
    if not lo then return true end
    return inst.maxLevel >= lo and inst.minLevel <= hi
end

local function Matches(inst, search)
    if search == "" then return true end
    if inst.name:lower():find(search, 1, true) then return true end
    for _, boss in ipairs(inst.bosses) do
        if boss.name:lower():find(search, 1, true) then return true end
    end
    return false
end

---------------------------------------------------------------------------
-- The page
---------------------------------------------------------------------------

function Home:Build(parent)
    page = CreateFrame("Frame", nil, parent)
    page:SetAllPoints()

    page.heading = J.TitleText(page, 26)
    page.heading:SetPoint("TOPLEFT", 20, -12)
    page.heading:SetTextColor(1, 0.82, 0)

    page.band = J.MakeDropdown(page, 150, J.BANDS, function() return J.db.band end, function(key)
        J.db.band = key
        J:Refresh(true)
    end)
    page.band:SetPoint("TOPRIGHT", -36, -14)

    page.soon = CreateFrame("CheckButton", nil, page, "UICheckButtonTemplate")
    page.soon:SetSize(24, 24)
    page.soon:SetPoint("RIGHT", page.band, "LEFT", -130, 0)
    local label = page.soon:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    label:SetPoint("LEFT", page.soon, "RIGHT", 2, 1)
    label:SetText("Show coming soon")
    page.soon:SetScript("OnClick", function(self)
        J.db.showSoon = self:GetChecked() and true or false
        J:Refresh(true)
    end)

    page.list = J.MakeList(page, ROW_H, InitRow)
    page.list:SetPoint("TOPLEFT", 20, -52)
    page.list:SetPoint("BOTTOMRIGHT", -28, 26)

    page.status = page:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    page.status:SetPoint("BOTTOMLEFT", 20, 8)

    page.empty = page:CreateFontString(nil, "OVERLAY", "GameFontDisable")
    page.empty:SetPoint("CENTER", page.list)
    page.empty:SetWidth(500)
    return page
end

function Home:Refresh(toTop)
    page.heading:SetText(J.TABS[J.db.tab])
    page.soon:SetChecked(J.db.showSoon)
    if page.band.Update then page.band:Update() end

    local instances = SpyGlass:GetInstances()
    if not instances then
        J.SetList(page.list, {}, true)
        page.empty:SetText(J.loadError or "Loading AtlasLoot...")
        page.empty:Show()
        page.status:SetText("")
        return
    end

    local raids = J.db.tab == 2
    local shown, soonCount, total = {}, 0, 0
    for _, inst in ipairs(instances) do
        if inst.isRaid == raids and InBand(inst) and Matches(inst, J.state.search) then
            total = total + 1
            if inst.comingSoon then soonCount = soonCount + 1 end
            if J.db.showSoon or not inst.comingSoon then shown[#shown + 1] = inst end
        end
    end

    local rows = {}
    for i = 1, #shown, COLUMNS do
        local row = {}
        for c = 0, COLUMNS - 1 do row[c + 1] = shown[i + c] end
        rows[#rows + 1] = row
    end
    J.SetList(page.list, rows, toTop)

    page.empty:SetShown(#shown == 0)
    page.empty:SetText("Nothing matches. Try another level range or search.")
    local noun = raids and "raids" or "dungeons"
    local status = total .. " " .. noun
    if soonCount > 0 then
        status = status .. "   |T" .. CLOCK .. ":14:14:0:0:64:64:5:59:5:59|t " .. soonCount
            .. " waiting for AtlasLoot to record their loot"
    end
    page.status:SetText(status)
end
