local _, F = ...

-- Titan Panel support (optional). With Titan loaded the pack icon lives on a
-- Titan bar and the collected buttons drop down from it in a column. Take the
-- plugin off the bar and the pack's own icon comes back.

local TITAN_ID = "FannyPack"

local function tooltipText()
    return "Left-click: " .. (F.db and F.db.expanded and "hide" or "show") .. " collected icons\n" ..
        "Right-click: open settings"
end

-- Called from ADDON_LOADED, before Titan registers its plugins on entering the world.
function F.CreateTitanPlugin()
    if F.titanButton or not TitanPanelButton_OnLoad then return end
    -- The template's OnLoad queues the button with Titan; the registry is read later.
    local ok, button = pcall(CreateFrame, "Button", "TitanPanel" .. TITAN_ID .. "Button", UIParent, "TitanPanelIconTemplate")
    if not ok or not button then return end
    button.registry = {
        id = TITAN_ID,
        category = "Interface",
        version = F.VERSION,
        menuText = "Fanny Pack",
        tooltipTitle = "|T" .. F.ICON .. ":16:16|t Fanny Pack",
        tooltipTextFunction = tooltipText,
        icon = F.ICON,
        iconWidth = 16,
        notes = "Straps every add-on's minimap button into one tidy pouch that drops down from the bar.",
        controlVariables = {
            ShowIcon = true,
            ShowLabelText = false,
            DisplayOnRightSide = true,
        },
        savedVariables = {
            ShowIcon = 1,
            ShowLabelText = false,
            DisplayOnRightSide = 1,
        },
    }
    F.titanButton = button

    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:SetScript("OnClick", function(_, mouseButton)
        if TitanPanelTooltip then TitanPanelTooltip:Hide() end
        GameTooltip:Hide()
        if not F.ready then return end
        if mouseButton == "RightButton" then
            F.ToggleOptions()
        elseif mouseButton == "LeftButton" then
            F.ToggleExpanded()
        end
    end)
    -- Titan shows the button when it puts it on a bar and hides it when taken off.
    local function modeChanged()
        if F.ready and not InCombatLockdown() then F.Layout(); F.SyncOptions() end
    end
    button:HookScript("OnShow", modeChanged)
    button:HookScript("OnHide", modeChanged)
end

-- Titan registers new plugins but leaves them off its bars until you tick
-- them. Put the pack on a bar once; after that, taking it off is respected.
local function onBar()
    if Titan_G and Titan_G.bars and Titan_G.bars.IsPluginShown then return Titan_G.bars.IsPluginShown(TITAN_ID) end
    if TitanPanel_IsPluginShown then return TitanPanel_IsPluginShown(TITAN_ID) end
    return true
end

function F.PlaceTitanPlugin()
    if not F.titanButton or F.db.titanPlaced then return end
    if Titan_G and Titan_G.InitializedPEW == false then return end
    if not (TitanUtils_IsPluginRegistered and TitanUtils_IsPluginRegistered(TITAN_ID)) then return end
    F.db.titanPlaced = true
    if onBar() then return end
    local pick = (Titan_G and Titan_G.plugins and Titan_G.plugins.PickBar) or TitanUtils_PickBar
    local bar = pick and pick()
    if bar and TitanUtils_AddButtonOnBar then
        TitanUtils_AddButtonOnBar(bar, TITAN_ID)
        F.Print("Added to your Titan bar. Right-click the Titan bar > Interface > Fanny Pack to remove it.")
    end
end

-- Whether the pack drops down from a Titan bar instead of using its own icon.
function F.UsingTitan()
    return F.titanButton ~= nil and F.titanButton:IsShown()
end
