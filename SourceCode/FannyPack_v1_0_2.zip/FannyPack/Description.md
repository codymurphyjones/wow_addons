# Fanny Pack

**Every add-on's minimap button, strapped into one tidy pouch, and the ones you've hidden actually stay hidden.**

Your minimap shouldn't look like a pincushion. Fanny Pack gathers the buttons your add-ons hang around the minimap and zips them into a single bar you can open and close with one click. It also respects your choices: when an add-on hides its own minimap button, Fanny Pack takes it out of the bar straight away, with no gaps and no reload.

---

## Getting started

1. **Disable Minimap Button: Forever** in the AddOns list if you use it. The two would fight over the same buttons.
2. **Log in.** Fanny Pack says *"Strapped on"* in chat, and the pack icon appears near the top of your screen.
3. **Left-click** the pack to open the bar and see your buttons. Left-click again to fold it away.
4. **Right-click** the pack to open settings, where you choose which buttons go where.
5. **To move the pack**, open **Edit Mode** (Esc > Edit Mode) and drag the blue box around the bar.

---

## Features

### One pouch for every button
- Gathers add-on minimap buttons into one bar, both LibDBIcon buttons and hand-made ones.
- Buttons from add-ons that load later are picked up on their own within a couple of seconds. To check straight away, use **Scan buttons** in settings or `/fp scan`.
- Buttons in the pack always show at full brightness, so none fade away like they can on the minimap.
- Folded, the bar is just the pack icon. Open, it shows every button you haven't hidden.
- Left alone on purpose:
  - Blizzard's own minimap controls: zoom, tracking, mail, clock and calendar, world map, queue status, instance difficulty and the add-on compartment.
  - Quest and map pins from Questie, GatherMate, HandyNotes and pfQuest.
  - Protected buttons, and anything on MinimapButtonBag's ignore list.

### Hidden means hidden
Most button bars force every button they collect to stay visible, so a button you turned off in an add-on's settings keeps coming back. Fanny Pack doesn't:
- When an add-on hides its button (through its own settings, LibDBIcon, or a plain `Hide()`), the button leaves the bar at once and the bar closes the gap.
- When the add-on shows it again, it rejoins the bar.
- A button that was already hidden before Fanny Pack gathered it stays hidden.
- In combat the bar catches up as soon as the fight ends.

### Three boxes: In the pack, Hidden, On the minimap
The **Buttons** section of settings shows every button Fanny Pack found, as icons in three boxes. **Drag an icon** from one box to another and the bar updates at once:
- **In the pack**: shown in the bar. This is where every button starts.
- **Hidden**: left out of the bar *and* off the minimap. Drag it back into In the pack to bring it back.
- **On the minimap**: left in its original place on the minimap, as if Fanny Pack had never touched it. It keeps its own fading, and you can still move it around the minimap as usual.

Good to know:
- Buttons hidden by their own add-on show in Hidden too, **greyed out**, so you can always see everything Fanny Pack found. These can't be dragged: show them again from that add-on's own settings.
- **Hover** any icon for its name and a reminder of what you can do with it.
- Buttons are remembered by name. A rare button with no name can still be hidden, but only until you reload.

### All characters, or just this one
- By default, what you hide or keep on the minimap applies to **all your characters**.
- Tick **Remember button choices for this character only** and your changes from then on apply to this character alone.
- A character's own choice for a button always beats the account's. You can show a button on one character that's hidden everywhere else, or the other way round.

### Your layout, your way
- **Horizontal or vertical** bar.
- **Icon size** from 20 to 64.
- **Spacing** between icons from 0 to 16.
- **Rows** from 1 to 6, to wrap a long bar into a block (columns on a vertical bar).
- **Min row size** from 1 to 20: with more than one row, the fewest icons in a row (the pack icon included) before the bar starts another row, so a short bar stays on one line. It only appears in settings when Rows is above 1.
- **Background** on or off.
- **Reset layout** puts everything back to the defaults.
- Layout and position are saved per character.

### Moving the pack with Edit Mode
- Open **Edit Mode** (Esc > Edit Mode). A **blue box** appears over the pack, just like Blizzard's own frames.
- **Drag** the blue box to move the pack anywhere on screen. **Right-click** it for settings.
- Close Edit Mode when you're done. The position is saved.
- The bar opens **inward from the nearest screen edge**, and extra rows stack away from it, so icons never fall off the screen.
- Outside Edit Mode the pack stays put, so you can't bump it by accident.

### Turning organising off
Untick **Organise add-on minimap buttons** and every button goes back to the minimap exactly as its add-on left it, including the ones you hid. Tick it again to gather them back up with all your choices intact.

### Safe in combat
- You can open and close the bar mid-fight.
- Rearranging, size changes and settings wait until combat ends, so nothing protected is ever touched.
- Every button keeps its own clicks and tooltips.

### Moving from Minimap Button: Forever
Fanny Pack is based on Minimap Button: Forever, and the first time you log in with both enabled it copies your layout (position, size, spacing and direction). Then disable Minimap Button: Forever and reload. Fanny Pack waits while both are enabled, so they don't fight over your buttons.

---

## Settings

Open settings by **right-clicking the pack**, typing `/fp`, or going to **Options > AddOns > Fanny Pack** (`/fp options`). The pop-up window can be dragged around, and it scrolls when it's taller than your screen.

From top to bottom:

| Setting | What it does |
|---|---|
| **Organise add-on minimap buttons** | Turn Fanny Pack's gathering on or off |
| **Use a vertical layout** | Bar runs up and down instead of side to side |
| **Show the bar background** | Dark backing and border behind the open bar |
| **Icon size** | 20 to 64 |
| **Spacing** | Gap between icons, 0 to 16 |
| **Rows** | Wrap the bar into 1 to 6 rows |
| **Min row size** | Fewest icons per row before a new row starts (shown with more than 1 row) |
| **Scan buttons** | Look for newly loaded minimap buttons now |
| **Reset layout** | Default position, size, spacing, rows, direction and background |
| **Remember button choices for this character only** | Save your box choices for this character instead of the account |
| **In the pack / Hidden / On the minimap** | Drag icons between the boxes to choose where each button goes |

---

## Controls

| | |
|---|---|
| **Left-click** the pack | Show or hide your buttons |
| **Right-click** the pack | Open or close settings |
| **Drag** the blue box in **Edit Mode** | Move the pack |
| **Right-click** the blue box in **Edit Mode** | Open or close settings |
| `/fp` or `/fannypack` | Open or close settings |
| `/fp options` | Settings in Options > AddOns |
| `/fp horizontal` / `/fp vertical` | Bar direction |
| `/fp size 40` | Icon size (20-64) |
| `/fp spacing 4` | Gap between icons (0-16) |
| `/fp rows 2` | Number of rows (1-6) |
| `/fp minrow 4` | Min row size (1-20) |
| `/fp scan` | Pick up newly loaded buttons |
| `/fp reset` | Default layout |
| `/fp status` | Version, layout, and how many buttons are hidden by their add-ons, hidden by you, or kept on the minimap |

---

## FAQ

**A button didn't show up in the pack.**
Type `/fp scan`. If it still doesn't appear, check the Hidden and On the minimap boxes in settings. A greyed-out icon in Hidden means its own add-on has hidden it.

**I can't move the pack.**
Open Edit Mode (Esc > Edit Mode) and drag the blue box.

**A greyed-out button won't drag.**
Its own add-on hid it. Turn its minimap button back on in that add-on's settings and it rejoins the pack.

**Fanny Pack says Minimap Button: Forever is enabled.**
Disable Minimap Button: Forever in the AddOns list and reload. Your layout has already been copied over.

**Settings won't open.**
You're in combat. Settings open as soon as the fight ends.

---

## Works great with

- **SpyGlass**: its "Hide AtlasLoot minimap button" setting takes effect straight away in Fanny Pack, with no reload.
- Any add-on using **LibDBIcon**: "hide minimap button" options are respected live.
- **MinimapButtonBag**'s ignore list: buttons it ignores, Fanny Pack ignores too.

---

## Notes

- Built for **World of Warcraft: Forever** (Interface 16001). No libraries required.
- Based on **Minimap Button: Forever** by Gideon, MIT licence. Thanks, Gideon!
- Please disable Minimap Button: Forever while using Fanny Pack.

Bug reports and suggestions are welcome in the comments or on the issue tracker.
