"""Draws the Fanny Pack logo: a leather belt pouch with three little round
minimap buttons peeking out of its open zip, on a dark round badge with a
gold rim (the same badge style as StatPriority's and LootPriority's).

Usage: python make_icon.py <output dir>
Writes <output dir>/Icon.tga (128x128, 32-bit, used in game) and
<output dir>/Logo.png (512x512, for CurseForge and other listings)."""
import os, sys
from PIL import Image, ImageDraw, ImageFilter

S = 1024                      # supersampled canvas, downscaled at the end
C = S / 2
img = Image.new("RGBA", (S, S), (0, 0, 0, 0))


def circle(d, r, fill=None, outline=None, width=0, cx=C, cy=C):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=fill, outline=outline, width=width)


# Soft drop shadow
shadow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
ImageDraw.Draw(shadow).ellipse([C - 470, C - 455, C + 470, C + 485], fill=(0, 0, 0, 170))
img = Image.alpha_composite(img, shadow.filter(ImageFilter.GaussianBlur(18)))
d = ImageDraw.Draw(img)

# Gold rim and dark badge
circle(d, 480, fill=(120, 82, 24))
circle(d, 462, fill=(214, 166, 64))
circle(d, 446, fill=(92, 60, 18))
circle(d, 432, fill=(22, 36, 36))

# Everything inside the badge is drawn on a layer clipped to the badge.
inside = Image.new("RGBA", (S, S), (0, 0, 0, 0))
glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
ImageDraw.Draw(glow).ellipse([C - 320, 300, C + 320, 760], fill=(70, 150, 140, 80))
inside = Image.alpha_composite(inside, glow.filter(ImageFilter.GaussianBlur(70)))
di = ImageDraw.Draw(inside)

LEATHER, LEATHER_DARK, LEATHER_LIGHT = (150, 86, 40), (88, 48, 20), (190, 120, 64)
STRAP, STRAP_DARK = (70, 42, 22), (40, 24, 12)
GOLD, GOLD_DARK = (232, 184, 70), (150, 104, 30)

# Belt strap running across the badge behind the pouch
di.rectangle([0, 560, S, 650], fill=STRAP_DARK)
di.rectangle([0, 570, S, 640], fill=STRAP)
for x in range(60, S, 70):  # stitching
    di.line([(x, 582), (x + 34, 582)], fill=(120, 84, 50), width=6)
    di.line([(x, 628), (x + 34, 628)], fill=(120, 84, 50), width=6)
# Buckle on the right
di.rounded_rectangle([800, 535, 900, 675], radius=16, outline=GOLD, width=22)
di.line([(850, 548), (850, 662)], fill=GOLD_DARK, width=14)

# Minimap buttons peeking out of the open zip (drawn before the pouch front)
for cx, cy, colour in ((C - 120, 420, (70, 130, 230)), (C + 10, 385, (170, 80, 220)), (C + 135, 425, (70, 190, 90))):
    circle(di, 74, fill=(30, 22, 12), cx=cx, cy=cy + 6)
    circle(di, 70, fill=GOLD, cx=cx, cy=cy)
    circle(di, 54, fill=GOLD_DARK, cx=cx, cy=cy)
    circle(di, 48, fill=colour, cx=cx, cy=cy)
    circle(di, 16, fill=tuple(min(255, c + 110) for c in colour), cx=cx - 16, cy=cy - 18)

# Pouch body
L, R, T, Bm = C - 270, C + 270, 450, 780
di.rounded_rectangle([L + 8, T + 14, R + 8, Bm + 14], radius=150, fill=(0, 0, 0, 120))
di.rounded_rectangle([L, T, R, Bm], radius=150, fill=LEATHER_DARK)
di.rounded_rectangle([L + 14, T + 12, R - 14, Bm - 14], radius=140, fill=LEATHER)
# front pocket
di.rounded_rectangle([L + 70, 590, R - 70, Bm - 50], radius=90, fill=LEATHER_DARK)
di.rounded_rectangle([L + 80, 598, R - 80, Bm - 60], radius=84, fill=LEATHER_LIGHT)
# zip along the top opening
di.line([(L + 60, T + 40), (R - 60, T + 40)], fill=(60, 60, 64), width=16)
for x in range(int(L + 70), int(R - 60), 22):
    di.line([(x, T + 30), (x, T + 50)], fill=(150, 150, 156), width=7)
# zip pull
di.rounded_rectangle([R - 110, T + 30, R - 70, T + 120], radius=12, fill=GOLD, outline=GOLD_DARK, width=6)
circle(di, 9, fill=GOLD_DARK, cx=R - 90, cy=T + 50)
# pocket zip
di.line([(L + 120, 640), (R - 120, 640)], fill=(60, 60, 64), width=12)
di.rounded_rectangle([C - 18, 640, C + 18, 700], radius=9, fill=GOLD, outline=GOLD_DARK, width=5)

# Leather sheen, on its own layer so it blends
shine = Image.new("RGBA", (S, S), (0, 0, 0, 0))
ImageDraw.Draw(shine).rounded_rectangle([L + 60, T + 70, R - 160, T + 110], radius=20, fill=(255, 220, 170, 60))
inside = Image.alpha_composite(inside, shine)

mask = Image.new("L", (S, S), 0)
ImageDraw.Draw(mask).ellipse([C - 432, C - 432, C + 432, C + 432], fill=255)
clipped = Image.new("RGBA", (S, S), (0, 0, 0, 0))
clipped.paste(inside, (0, 0), Image.composite(inside.split()[3], Image.new("L", (S, S), 0), mask))
img = Image.alpha_composite(img, clipped)

# Inner shadow under the rim
ring = Image.new("RGBA", (S, S), (0, 0, 0, 0))
ImageDraw.Draw(ring).ellipse([C - 440, C - 440, C + 440, C + 440], outline=(0, 0, 0, 140), width=22)
img = Image.alpha_composite(img, ring.filter(ImageFilter.GaussianBlur(8)))

out_dir = sys.argv[1]
os.makedirs(out_dir, exist_ok=True)
icon = img.resize((128, 128), Image.LANCZOS)
icon.save(os.path.join(out_dir, "Icon.tga"))
img.resize((512, 512), Image.LANCZOS).save(os.path.join(out_dir, "Logo.png"))
print("saved", os.path.join(out_dir, "Icon.tga"), "and Logo.png")
