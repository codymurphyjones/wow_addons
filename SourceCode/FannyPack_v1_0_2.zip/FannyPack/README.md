# Fanny Pack

Straps every add-on's minimap button into one tidy pouch beside your minimap, and leaves out
any button its own add-on hid. Based on Minimap Button: Forever by Gideon (MIT licence).

## What's different from Minimap Button: Forever

Minimap Button: Forever keeps every button it gathered visible, so when an add-on hides its
own button (for example AtlasLoot's, from SpyGlass's settings), it pops straight back until
you reload. Fanny Pack respects that choice:

- A button is left out of the bar when its add-on calls `Hide()` (or `SetShown(false)`) on
  it, or when it's a LibDBIcon button whose saved settings say `hide`.
- The bar closes the gap straight away. In combat it catches up as soon as the fight ends.
- When the add-on shows its button again, it rejoins the bar.
- A button that was already hidden when Fanny Pack gathered it stays out until its add-on
  shows it.
- Releasing buttons (unticking "Organise add-on minimap buttons") puts them back on the
  minimap still hidden or shown, as their add-on left them.

## Choosing where buttons go

Open settings (right-click the pack, `/fp`, or Options > AddOns > Fanny Pack). Under
**Buttons**, every collected button sits in one of three boxes:

- **In the pack**: shown in the bar.
- **Hidden**: left out of the bar and off the minimap. Buttons their own add-on hid also show
  here, greyed out. Show those from that add-on's settings instead.
- **On the minimap**: left in its original place on the minimap, as if Fanny Pack had never
  collected it. It keeps its own fading and can still be moved around the minimap as usual.

Drag an icon from one box to the other. The bar updates at once (in combat, the gap closes as
soon as the fight ends). Turning off "Organise add-on minimap buttons" gives every button back
to the minimap, including the ones you hid.

**Where it's saved:** by default, what you hide or keep on the minimap applies to all your characters
(`FannyPackAccountDB`). Tick **Remember button choices for this character only** and your
changes from then on apply only to that character. A character's own choice for a button
always beats the account's, so you can show a button on one character that's hidden
everywhere else, or the other way round. Buttons are remembered by name.

Everything else works as before: a horizontal or vertical bar (now in rows if you like, see
**Rows** and **Min row size** in settings), icon size and spacing,
background, moving the bar in Edit Mode, and combat-safe changes.

## Installing

Disable **Minimap Button: Forever** in the AddOns list: the two would fight over the same
buttons, so Fanny Pack waits (and says so) while both are enabled. The first time you log in
with both enabled, Fanny Pack copies your Minimap Button: Forever layout (position, size,
spacing, orientation), so disable it afterwards and reload to pick up where you left off.

## Controls

| | |
|---|---|
| Left-click the pack | Show or hide the collected icons |
| Right-click the pack | Open or close settings |
| Drag the pack in Edit Mode (Esc > Edit Mode) | Move the bar |
| `/fp` or `/fannypack` | Open or close settings |
| `/fp options` | Open Options > AddOns > Fanny Pack |
| `/fp horizontal`, `/fp vertical` | Bar direction |
| `/fp size 40` | Icon size, 20 to 64 |
| `/fp spacing 4` | Gap between icons, 0 to 16 |
| `/fp rows 2` | Wrap the bar into up to 1 to 6 rows (columns on a vertical bar) |
| `/fp minrow 4` | With more than one row: the fewest icons in a row (pack icon included) before another row starts, 1 to 20 |
| `/fp scan` | Look for newly loaded minimap buttons |
| `/fp reset` | Restore the default layout |
| `/fp status` | Version, layout, and how many buttons are hidden (by their add-ons, and by you) or kept on the minimap |

Layout settings save per character (`FannyPackDB`); button choices save as described above. The logo is drawn by `Media\make_icon.py`.
