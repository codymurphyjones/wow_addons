local _, F = ...

local function setBackdrop(frame)
    frame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 12,
        insets = {left = 3, right = 3, top = 3, bottom = 3},
    })
end

local function requestLayout()
    if F.layoutPending or F.layingOut or InCombatLockdown() then return end
    F.layoutPending = true
    C_Timer.After(0, function()
        F.layoutPending = false
        if F.ready and not F.dragging and not InCombatLockdown() then F.Layout() end
    end)
end

-- Shows or hides a collected button for Fanny Pack's own layout. The
-- Show/Hide hooks below ignore these calls, so they only record what the
-- button's own add-on asks for.
function F.SetButtonShown(button, shown)
    if shown == (button:IsShown() and true or false) then return end
    F.selfVisibility = true
    if shown then button:Show() else button:Hide() end
    F.selfVisibility = false
end

-- The button's add-on hid or showed it: remember that, and rebuild the bar
-- so a hidden button leaves no gap. In combat the bar catches up afterwards.
local function ownerSetShown(button, shown)
    local info = F.collectedByButton and F.collectedByButton[button]
    if not info or F.selfVisibility then return end
    info.ownerHidden = not shown
    requestLayout()
end

-- Whether the bar is holding this button (not one you keep on the minimap),
-- and isn't the one moving it right now.
local function inPack(button)
    local info = F.collectedByButton and F.collectedByButton[button]
    return info and not info.home and not F.layingOut
end

local function watchCollectedButton(button)
    if button.FannyPackWatched then return end
    button.FannyPackWatched = true
    hooksecurefunc(button, "SetParent", function()
        if inPack(button) then requestLayout() end
    end)
    hooksecurefunc(button, "SetPoint", function()
        if inPack(button) then requestLayout() end
    end)
    hooksecurefunc(button, "SetScale", function()
        if inPack(button) then requestLayout() end
    end)
    hooksecurefunc(button, "SetSize", function()
        if inPack(button) then requestLayout() end
    end)
    hooksecurefunc(button, "SetWidth", function()
        if inPack(button) then requestLayout() end
    end)
    hooksecurefunc(button, "SetHeight", function()
        if inPack(button) then requestLayout() end
    end)
    hooksecurefunc(button, "SetAlpha", function(_, alpha)
        if alpha ~= 1 and inPack(button) then requestLayout() end
    end)
    hooksecurefunc(button, "Hide", function() ownerSetShown(button, false) end)
    hooksecurefunc(button, "Show", function() ownerSetShown(button, true) end)
    hooksecurefunc(button, "SetShown", function(_, shown) ownerSetShown(button, shown and true or false) end)
end

-- Which corner of the bar the pack icon sits in. The bar opens inward from
-- it, and extra rows stack away from the nearer screen edge. On a Titan bar
-- the drop-down opens away from the screen edge the Titan icon is nearest.
local function titanOffset()
    local x, y = F.titanButton:GetCenter()
    local px, py = UIParent:GetCenter()
    local scale = F.titanButton:GetEffectiveScale() / UIParent:GetEffectiveScale()
    if not x or not px then return 0, 1 end
    return x * scale - px, y * scale - py
end
local function fromRight()
    if F.UsingTitan() then return (titanOffset()) > 0 end
    return F.db.x > 0
end
local function fromTop()
    if F.UsingTitan() then return select(2, titanOffset()) >= 0 end
    return F.db.y >= 0
end

function F.ApplyPosition()
    if not F.container or F.dragging then return end
    if F.UsingTitan() then
        -- Drop down from (or up from) the Titan icon, clear of the bar.
        local side = fromRight() and "RIGHT" or "LEFT"
        F.container:ClearAllPoints()
        if fromTop() then
            F.container:SetPoint("TOP" .. side, F.titanButton, "BOTTOM" .. side, 0, -4)
        else
            F.container:SetPoint("BOTTOM" .. side, F.titanButton, "TOP" .. side, 0, 4)
        end
        return
    end
    local width, height = F.container:GetSize()
    local size = F.db.size
    -- Keep the pack icon at the saved spot, wherever it sits in the bar.
    local launcherOffsetX = width / 2 - 4 - size / 2
    local launcherOffsetY = height / 2 - 4 - size / 2
    if not fromRight() then launcherOffsetX = -launcherOffsetX end
    if not fromTop() then launcherOffsetY = -launcherOffsetY end
    F.container:ClearAllPoints()
    F.container:SetPoint("CENTER", UIParent, "CENTER", F.db.x - launcherOffsetX, F.db.y - launcherOffsetY)
end

function F.SavePosition()
    local x, y = F.launcher:GetCenter()
    local px, py = UIParent:GetCenter()
    if x and y and px and py then
        F.db.x, F.db.y = x - px, y - py
    end
end

-- Edit Mode -----------------------------------------------------------------
-- The pack moves only while Blizzard's Edit Mode is open. A client without
-- Edit Mode lets you drag the pack icon at any time instead.

function F.HasEditMode()
    return EditModeManagerFrame ~= nil and EventRegistry ~= nil
end

function F.IsEditing()
    if not F.HasEditMode() then return true end
    local manager = EditModeManagerFrame
    if manager.IsEditModeActive then return manager:IsEditModeActive() end
    return manager:IsShown()
end

-- Called when Edit Mode opens or closes.
function F.UpdateEditState()
    if not F.editOverlay then return end
    -- On a Titan bar the pack goes where Titan puts its icon.
    local editing = F.HasEditMode() and F.IsEditing() and not F.UsingTitan()
    F.editOverlay:SetShown(editing)
    if not editing and F.dragging then F.StopDrag() end
end

function F.ReleaseButtons()
    if InCombatLockdown() or not F.collected then return end
    for _, info in ipairs(F.collected) do
        -- A button you keep on the minimap is already there.
        if not info.home then F.RestoreButton(info) end
        -- Back on the minimap, a button you hid shows again unless its add-on hid it.
        F.SetButtonShown(info.button, not F.IsOwnerHidden(info))
    end
    F.collected, F.collectedByButton = {}, {}
    F.Layout()
end

function F.ScanButtons(report)
    if InCombatLockdown() or F.dragging or not Minimap or not F.container then return end
    if not F.db.enabled then
        F.ReleaseButtons()
        return
    end
    for index = #F.collected, 1, -1 do
        local info = F.collected[index]
        if F.IsBlizzardMinimapControl(info.button) then
            F.collectedByButton[info.button] = nil
            table.remove(F.collected, index)
            F.RestoreButton(info)
        end
    end
    local added, seen = 0, {}
    local children = {}
    local function addChildren(frame, depth)
        if not frame or not frame.GetChildren or depth > 6 then return end
        for _, child in ipairs({frame:GetChildren()}) do
            if not seen[child] then
                seen[child] = true
                children[#children + 1] = child
                addChildren(child, depth + 1)
            end
        end
    end
    addChildren(Minimap, 0)
    local minimapParent = Minimap:GetParent()
    addChildren(minimapParent, 0)
    if UIParent and UIParent.GetChildren then
        for _, child in ipairs({UIParent:GetChildren()}) do
            if not seen[child] then
                seen[child] = true
                children[#children + 1] = child
            end
        end
    end
    for _, button in ipairs(children) do
        if F.IsCollectable(button) and not F.collectedByButton[button] then
            local info = F.CaptureButton(button)
            F.collected[#F.collected + 1] = info
            F.collectedByButton[button] = info
            watchCollectedButton(button)
            if F.IsKeptOnMinimap(info) then
                -- You keep this one on the minimap: leave it as it is.
                info.home = true
            else
                F.BrightenButton(info)
                -- Button-bag add-ons sometimes install an OnShow handler whose only
                -- job is to hide the button again. The original is restored on release.
                button:SetScript("OnShow", nil)
                button:SetParent(F.buttonHolder)
            end
            added = added + 1
        end
    end
    table.sort(F.collected, function(left, right) return left.order < right.order end)
    F.Layout()
    if report then F.Print("Scan complete: " .. added .. " new, " .. #F.collected .. " total button(s).") end
end

function F.ApplyExpandedVisibility()
    if not F.buttonHolder or not F.background then return end
    -- Buttons their add-on hid, or you hid, stay hidden whether the bar is open or not.
    for _, info in ipairs(F.collected or {}) do
        local button = info.button
        if button and not (button.IsProtected and button:IsProtected()) then
            -- On the minimap only its own add-on decides.
            local hidden
            if info.home then hidden = F.IsOwnerHidden(info) else hidden = F.IsHidden(info) end
            F.SetButtonShown(button, not hidden)
        end
    end
    F.buttonHolder:SetShown(F.db.expanded)
    F.background:SetShown(F.db.expanded)
end

function F.ToggleExpanded()
    F.db.expanded = not F.db.expanded
    if InCombatLockdown() then
        F.ApplyExpandedVisibility()
    else
        F.Layout()
    end
end

function F.Layout()
    if InCombatLockdown() or not F.container then return end
    F.layingOut = true
    local size, spacing = F.db.size, F.db.spacing
    -- On a Titan bar the icon lives on the bar, and the buttons drop down in a column.
    local titan = F.UsingTitan()
    local vertical = titan or F.db.vertical
    F.launcher:SetShown(not titan)
    local visible = {}
    for _, info in ipairs(F.collected or {}) do
        local button = info.button
        if button and F.IsKeptOnMinimap(info) then
            F.SendHome(info)
        elseif button then
            F.TakeFromHome(info)
            F.BrightenButton(info)
            button:SetParent(F.buttonHolder)
            if F.IsHidden(info) then
                F.SetButtonShown(button, false)
            else
                F.SetButtonShown(button, true)
                visible[#visible + 1] = button
            end
        end
    end
    -- Icons per row: enough to fit everything in the chosen number of rows,
    -- but never fewer than the minimum row size (so a short bar stays one row).
    local fullCount = titan and math.max(1, #visible) or 1 + #visible
    local perRow = math.ceil(fullCount / F.db.rows)
    if F.db.rows > 1 then perRow = math.max(perRow, F.db.minRowSize) end
    perRow = math.min(perRow, fullCount)
    local lines = math.ceil(fullCount / perRow)
    local function extent(cells) return cells * size + math.max(0, cells - 1) * spacing + 8 end
    -- Folded, the bar is just the pack icon.
    local along = F.db.expanded and extent(perRow) or extent(1)
    local across = F.db.expanded and extent(lines) or extent(1)
    local fullAlong, fullAcross = extent(perRow), extent(lines)
    if vertical then
        F.container:SetSize(across, along)
        F.background:SetSize(fullAcross, fullAlong)
        F.buttonHolder:SetSize(fullAcross, fullAlong)
    else
        F.container:SetSize(along, across)
        F.background:SetSize(fullAlong, fullAcross)
        F.buttonHolder:SetSize(fullAlong, fullAcross)
    end
    F.background:SetBackdropColor(0.025, 0.02, 0.015, F.db.showBackground and 0.86 or 0)
    F.background:SetBackdropBorderColor(0.68, 0.48, 0.18, F.db.showBackground and 1 or 0)

    local corner = (fromTop() and "TOP" or "BOTTOM") .. (fromRight() and "RIGHT" or "LEFT")
    local signX, signY = fromRight() and -1 or 1, fromTop() and -1 or 1
    F.background:ClearAllPoints()
    F.buttonHolder:ClearAllPoints()
    F.background:SetPoint(corner, F.container, corner)
    F.buttonHolder:SetPoint(corner, F.container, corner)

    F.ApplyExpandedVisibility()
    for _, info in ipairs(F.collected or {}) do
        if info.slot then info.slot:Hide() end
    end

    local buttons = titan and {} or {F.launcher}
    for _, button in ipairs(visible) do buttons[#buttons + 1] = button end
    for index, button in ipairs(buttons) do
        local info = F.collectedByButton and F.collectedByButton[button]
        if info and info.isLibDBIcon then
            if button.SetFixedFrameLevel then button:SetFixedFrameLevel(false) end
            if button.SetFixedFrameStrata then button:SetFixedFrameStrata(false) end
        end
        button:ClearAllPoints()
        local anchor = button
        if info then
            -- SetPoint offsets are evaluated in the anchored frame's scale.
            -- Anchoring a scaled third-party button directly at a bar-sized
            -- offset therefore makes its position drift as the slider moves.
            -- Keep every positional offset on an unscaled slot and place the
            -- complete third-party button at the slot's zero-offset centre.
            if not info.slot then
                info.slot = CreateFrame("Frame", nil, F.buttonHolder)
                info.slot:EnableMouse(false)
            end
            anchor = info.slot
            anchor:SetParent(F.buttonHolder)
            anchor:SetScale(1)
            anchor:SetSize(size, size)
            anchor:ClearAllPoints()
            anchor:Show()

            button:SetParent(F.buttonHolder)
            local originalWidth = math.max(1, tonumber(info.width) or size)
            local originalHeight = math.max(1, tonumber(info.height) or size)
            local originalExtent = math.max(originalWidth, originalHeight)
            button:SetSize(originalWidth, originalHeight)
            button:SetScale(size / originalExtent)
        else
            button:SetScale(1)
            button:SetSize(size, size)
        end
        button:SetFrameStrata("MEDIUM")
        button:SetFrameLevel(F.buttonHolder:GetFrameLevel() + 2)
        local alongOffset = 4 + size / 2 + ((index - 1) % perRow) * (size + spacing)
        local acrossOffset = 4 + size / 2 + math.floor((index - 1) / perRow) * (size + spacing)
        if vertical then
            anchor:SetPoint("CENTER", F.container, corner, signX * acrossOffset, signY * alongOffset)
        else
            anchor:SetPoint("CENTER", F.container, corner, signX * alongOffset, signY * acrossOffset)
        end
        if info then button:SetPoint("CENTER", anchor, "CENTER", 0, 0) end
    end
    F.launcher.icon:SetSize(math.max(12, size - 8), math.max(12, size - 8))
    F.ApplyPosition()
    F.layingOut = false
    F.RefreshButtonBoxes()
end

local function launcherTooltip()
    GameTooltip:SetOwner(F.launcher, "ANCHOR_RIGHT")
    GameTooltip:SetText("|T" .. F.ICON .. ":16:16|t Fanny Pack", 1, 0.82, 0.3)
    GameTooltip:AddLine(F.db.expanded and "Left-click: hide collected icons" or "Left-click: show collected icons", 1, 1, 1)
    GameTooltip:AddLine("Right-click: open settings", 1, 1, 1)
    GameTooltip:AddLine(F.HasEditMode() and "Open Edit Mode to move the pack" or "Drag: move the button bar", 0.72, 0.72, 0.72)
    GameTooltip:AddLine((F.db.vertical and "Vertical" or "Horizontal") .. " layout - size " .. F.db.size, 0.72, 0.9, 0.72)
    GameTooltip:Show()
end

function F.BuildUI()
    if F.container then return end
    F.collected, F.collectedByButton = {}, {}

    local container = CreateFrame("Frame", "FannyPackBar", UIParent, "BackdropTemplate")
    F.container = container
    container:SetFrameStrata("MEDIUM")
    container:SetFrameLevel(10)
    container:SetMovable(true)
    -- The bar can be wider than its controller. Clamping the whole bar makes
    -- the controller fall behind the cursor near a screen edge.
    container:SetClampedToScreen(false)
    local background = CreateFrame("Frame", "FannyPackBackground", container, "BackdropTemplate")
    F.background = background
    background:SetFrameStrata("MEDIUM")
    background:SetFrameLevel(container:GetFrameLevel())
    if background.SetFixedFrameLevel then background:SetFixedFrameLevel(true) end
    background:EnableMouse(false)
    setBackdrop(background)

    local buttonHolder = CreateFrame("Frame", "FannyPackButtonHolder", container)
    F.buttonHolder = buttonHolder
    buttonHolder:SetFrameStrata("MEDIUM")
    buttonHolder:SetFrameLevel(container:GetFrameLevel() + 10)
    buttonHolder.brightnessElapsed = 0
    buttonHolder:SetScript("OnUpdate", function(self, elapsed)
        self.brightnessElapsed = self.brightnessElapsed + elapsed
        if self.brightnessElapsed < 0.2 then return end
        self.brightnessElapsed = 0
        if InCombatLockdown() then return end
        for _, info in ipairs(F.collected or {}) do
            -- Buttons on the minimap keep their own fading.
            if not info.home then F.BrightenButton(info) end
        end
    end)

    local launcher = CreateFrame("Button", "FannyPackLauncher", container, "BackdropTemplate")
    F.launcher = launcher
    launcher:SetFrameStrata("MEDIUM")
    launcher:SetFrameLevel(buttonHolder:GetFrameLevel() + 2)
    launcher:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    launcher:RegisterForDrag("LeftButton")
    launcher:EnableMouse(true)
    launcher:SetBackdrop({bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 10,
        insets = {left = 2, right = 2, top = 2, bottom = 2}})
    launcher:SetBackdropColor(0.12, 0.08, 0.02, 1)
    launcher:SetBackdropBorderColor(1, 0.72, 0.2, 1)
    launcher.icon = launcher:CreateTexture(nil, "ARTWORK")
    launcher.icon:SetPoint("CENTER")
    launcher.icon:SetTexture(F.ICON)
    launcher:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
    launcher:SetScript("OnEnter", launcherTooltip)
    launcher:SetScript("OnLeave", function() GameTooltip:Hide() end)
    launcher:SetScript("OnClick", function(_, mouseButton)
        if GetTime() < (launcher.ignoreClickUntil or 0) then return end
        if mouseButton == "RightButton" then
            F.ToggleOptions()
        else
            F.ToggleExpanded()
            if GameTooltip:IsOwned(launcher) then launcherTooltip() end
        end
    end)
    local function startDrag()
        if InCombatLockdown() or F.dragging or not F.IsEditing() or F.UsingTitan() then return end
        GameTooltip:Hide()
        F.dragging = true
        local cursorX, cursorY = GetCursorPosition()
        local scale = UIParent:GetEffectiveScale()
        local containerX, containerY = container:GetCenter()
        local parentX, parentY = UIParent:GetCenter()
        if not cursorX or not cursorY or not scale or scale == 0 or
                not containerX or not containerY or not parentX or not parentY then
            F.dragging = false
            return
        end
        F.dragCursorX, F.dragCursorY = cursorX / scale, cursorY / scale
        F.dragContainerX, F.dragContainerY = containerX - parentX, containerY - parentY
        container:SetScript("OnUpdate", function()
            local currentX, currentY = GetCursorPosition()
            local currentScale = UIParent:GetEffectiveScale()
            if not currentX or not currentY or not currentScale or currentScale == 0 then return end
            local x = F.dragContainerX + currentX / currentScale - F.dragCursorX
            local y = F.dragContainerY + currentY / currentScale - F.dragCursorY
            container:ClearAllPoints()
            container:SetPoint("CENTER", UIParent, "CENTER", x, y)
        end)
    end
    function F.StopDrag()
        if not F.dragging then return end
        container:SetScript("OnUpdate", nil)
        F.dragging = false
        F.dragCursorX, F.dragCursorY = nil, nil
        F.dragContainerX, F.dragContainerY = nil, nil
        launcher.ignoreClickUntil = GetTime() + 0.2
        F.SavePosition()
        F.Layout()
    end
    -- With Edit Mode the selection overlay takes the drag instead.
    if not F.HasEditMode() then
        launcher:SetScript("OnDragStart", startDrag)
        launcher:SetScript("OnDragStop", F.StopDrag)
    end

    -- Edit Mode selection overlay over the bar: drag to move the pack,
    -- right-click for settings.
    local overlay = CreateFrame("Frame", "FannyPackEditOverlay", container, "BackdropTemplate")
    F.editOverlay = overlay
    overlay:SetAllPoints(container)
    overlay:SetFrameStrata("DIALOG")
    overlay:SetBackdrop({bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 2})
    overlay:SetBackdropColor(0.0, 0.44, 0.87, 0.25)
    overlay:SetBackdropBorderColor(0.3, 0.65, 1, 1)
    overlay:EnableMouse(true)
    overlay:RegisterForDrag("LeftButton")
    overlay:SetScript("OnDragStart", startDrag)
    overlay:SetScript("OnDragStop", F.StopDrag)
    overlay:SetScript("OnMouseUp", function(_, mouseButton)
        if mouseButton == "RightButton" then F.ToggleOptions() end
    end)
    overlay:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("|T" .. F.ICON .. ":16:16|t Fanny Pack", 1, 0.82, 0.3)
        GameTooltip:AddLine("Drag: move the pack", 1, 1, 1)
        GameTooltip:AddLine("Right-click: open settings", 1, 1, 1)
        GameTooltip:Show()
    end)
    overlay:SetScript("OnLeave", function() GameTooltip:Hide() end)
    overlay:Hide()
    F.ApplyPosition()
    F.Layout()
end

local function createSlider(parent, name, y, lowValue, highValue, valueStep, onChanged)
    local slider = CreateFrame("Slider", name, parent, "BackdropTemplate")
    slider:SetPoint("TOP", 0, y)
    slider:SetSize(270, 16)
    slider:SetOrientation("HORIZONTAL")
    slider:SetMinMaxValues(lowValue, highValue)
    slider:SetValueStep(valueStep)
    slider:SetObeyStepOnDrag(true)
    slider:SetBackdrop({bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 8})
    slider:SetBackdropColor(0.08, 0.07, 0.05, 1)
    local thumb = slider:CreateTexture(nil, "ARTWORK")
    thumb:SetTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
    thumb:SetSize(24, 24)
    slider:SetThumbTexture(thumb)
    local low = slider:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    low:SetPoint("TOPLEFT", slider, "BOTTOMLEFT", 0, -2); low:SetText(tostring(lowValue))
    local high = slider:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    high:SetPoint("TOPRIGHT", slider, "BOTTOMRIGHT", 0, -2); high:SetText(tostring(highValue))
    slider.label = slider:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    slider.label:SetPoint("BOTTOM", slider, "TOP", 0, 5)
    slider:SetScript("OnValueChanged", function(_, value)
        if not F.syncingOptions then onChanged(value) end
    end)
    return slider
end

-- Height the row sliders add to the page, above the scan buttons.
local function sliderSpace()
    return F.db.rows > 1 and 130 or 65
end

function F.SyncOptions()
    local content = F.optionsContent
    if not content then return end
    F.syncingOptions = true
    content.enabled:SetChecked(F.db.enabled)
    content.vertical:SetChecked(F.db.vertical)
    -- A Titan drop-down is always a column.
    content.vertical:SetShown(not F.UsingTitan())
    content.help:SetText(F.HelpText())
    content.background:SetChecked(F.db.showBackground)
    content.size:SetValue(F.db.size)
    content.size.label:SetText("Icon size: " .. F.db.size)
    content.spacing:SetValue(F.db.spacing)
    content.spacing.label:SetText("Spacing: " .. F.db.spacing)
    content.rows:SetValue(F.db.rows)
    content.rows.label:SetText("Rows: " .. F.db.rows)
    content.minRowSize:SetValue(F.db.minRowSize)
    content.minRowSize.label:SetText("Min row size: " .. F.db.minRowSize)
    content.scope:SetChecked(F.db.hiddenScope == "character")
    F.syncingOptions = false
    -- Min row size only matters with more than one row; what's below moves up when it's hidden.
    content.minRowSize:SetShown(F.db.rows > 1)
    local top = sliderSpace()
    content.scan:SetPoint("TOP", -62, -325 - top)
    content.reset:SetPoint("TOP", 62, -325 - top)
    content.header:SetPoint("TOPLEFT", 24, -370 - top)
end

---------------------------------------------------------------------------
-- The Buttons section: drag icons between "In the pack" and "Hidden"
---------------------------------------------------------------------------

local TILE, GAP, COLUMNS = 32, 4, 8
local BOX_WIDTH = COLUMNS * (TILE + GAP) - GAP + 12
local QUESTION_MARK = "Interface\\Icons\\INV_Misc_QuestionMark"
local PACK_BORDER, HIDDEN_BORDER, LIT_BORDER = {0.68, 0.48, 0.18}, {0.75, 0.25, 0.25}, {1, 0.85, 0.3}
local MINIMAP_BORDER = {0.3, 0.55, 0.8}
-- The pop-up's page starts below its close button.
local POPUP_TOP, POPUP_BOTTOM = 30, 10

local function tryCopyIcon(dest, info)
    local source = F.ButtonIcon(info)
    if not source then return false end
    local atlas = source.GetAtlas and source:GetAtlas()
    if atlas then
        dest:SetAtlas(atlas)
    else
        dest:SetTexture(source:GetTexture())
        if source.GetTexCoord then dest:SetTexCoord(source:GetTexCoord()) end
    end
    return true
end

-- Copies a button's icon onto dest; no icon, or an error copying it, gets the
-- question mark. Some icons copy fine but draw nothing (masked ones, say), so
-- tiles also keep a dark square underneath (see withPlaceholder).
local function copyIcon(dest, info)
    local ok, copied = pcall(tryCopyIcon, dest, info)
    if not (ok and copied) then
        dest:SetTexture(QUESTION_MARK)
        dest:SetTexCoord(0, 1, 0, 1)
    end
end

-- A dark square under frame's icon: a backdrop for see-through icons, and
-- something to see and drag when the icon draws nothing.
local function withPlaceholder(frame)
    local placeholder = frame:CreateTexture(nil, "BACKGROUND")
    placeholder:SetAllPoints()
    placeholder:SetColorTexture(0.12, 0.12, 0.12, 0.9)
    frame.placeholder = placeholder
end

local function tileTooltip(tile)
    local info = tile.info
    if not info then return end
    GameTooltip:SetOwner(tile, "ANCHOR_RIGHT")
    GameTooltip:SetText(F.ButtonLabel(info), 1, 0.82, 0.3)
    if F.IsOwnerHidden(info) then
        GameTooltip:AddLine("Hidden by its own add-on. Show it from that add-on's settings.", 0.8, 0.8, 0.8, true)
    elseif not info.button:GetName() then
        GameTooltip:AddLine("This button has no name, so hiding it only lasts until you reload.", 0.8, 0.8, 0.8, true)
    elseif F.IsUserHidden(info) then
        GameTooltip:AddLine("Drag into In the pack to show it again.", 0.8, 0.8, 0.8, true)
    elseif F.IsKeptOnMinimap(info) then
        GameTooltip:AddLine("Stays in its own place on the minimap. Drag into In the pack to collect it.", 0.8, 0.8, 0.8, true)
    else
        GameTooltip:AddLine("Drag into Hidden to leave it out of the pack, or On the minimap to keep it in its own place.", 0.8, 0.8, 0.8, true)
    end
    GameTooltip:Show()
end

-- Which box the cursor is over, if any.
local function boxUnderCursor()
    local content = F.optionsContent
    -- A box scrolled out of view can't be dropped on.
    local scroll = content:GetParent() and content:GetParent():GetParent()
    if scroll and scroll.IsMouseOver and not scroll:IsMouseOver() then return end
    if content.minimapBox:IsMouseOver() then return content.minimapBox end
    if content.hiddenBox:IsMouseOver() then return content.hiddenBox end
    if content.packBox:IsMouseOver() then return content.packBox end
end

local function paintBorders(lit)
    local content = F.optionsContent
    for _, box in ipairs({content.packBox, content.hiddenBox, content.minimapBox}) do
        local color = box == lit and LIT_BORDER or box.border
        box:SetBackdropBorderColor(color[1], color[2], color[3], 1)
    end
end

local function dragGhost()
    if F.tileGhost then return F.tileGhost end
    local ghost = CreateFrame("Frame", nil, UIParent)
    ghost:SetSize(TILE, TILE)
    ghost:SetFrameStrata("TOOLTIP")
    ghost:EnableMouse(false)
    withPlaceholder(ghost)
    ghost.icon = ghost:CreateTexture(nil, "ARTWORK")
    ghost.icon:SetAllPoints()
    ghost:Hide()
    ghost:SetScript("OnUpdate", function(self)
        local x, y = GetCursorPosition()
        local scale = UIParent:GetEffectiveScale()
        self:ClearAllPoints()
        self:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x / scale, y / scale)
        paintBorders(boxUnderCursor())
    end)
    F.tileGhost = ghost
    return ghost
end

local function startTileDrag(tile)
    local info = tile.info
    if not info or F.IsOwnerHidden(info) then return end
    GameTooltip:Hide()
    local ghost = dragGhost()
    copyIcon(ghost.icon, info)
    ghost:Show()
    F.draggingTile = tile
    tile:SetAlpha(0.35)
end

-- Ends a tile drag; apply = false (the page closed mid-drag) drops nothing.
local function stopTileDrag(apply)
    local tile = F.draggingTile
    if not tile then return end
    F.draggingTile = nil
    tile:SetAlpha(1)
    F.tileGhost:Hide()
    local target = apply ~= false and boxUnderCursor()
    paintBorders(nil)
    if target == F.optionsContent.hiddenBox then
        F.SetPlacement(tile.info, "hidden")
    elseif target == F.optionsContent.minimapBox then
        F.SetPlacement(tile.info, "minimap")
    elseif target == F.optionsContent.packBox then
        F.SetPlacement(tile.info, "pack")
    end
end

local function makeBox(content, label, border, anchor, offsetY)
    local title = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, offsetY)
    title:SetText(label)
    local box = CreateFrame("Frame", nil, content, "BackdropTemplate")
    box:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -4)
    box:SetWidth(BOX_WIDTH)
    setBackdrop(box)
    box.border = border
    box:SetBackdropColor(border[1] * 0.12, border[2] * 0.12, border[3] * 0.12, 0.85)
    box:SetBackdropBorderColor(border[1], border[2], border[3], 1)
    box.empty = box:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    box.empty:SetPoint("CENTER")
    box.empty:SetText("Drop buttons here")
    box.title = title
    return box
end

local function tileFor(info)
    if info.tile then return info.tile end
    local tile = CreateFrame("Button", nil, F.optionsContent)
    tile:SetSize(TILE, TILE)
    tile:RegisterForDrag("LeftButton")
    withPlaceholder(tile)
    tile.icon = tile:CreateTexture(nil, "ARTWORK")
    tile.icon:SetAllPoints()
    local highlight = tile:CreateTexture(nil, "HIGHLIGHT")
    highlight:SetAllPoints()
    highlight:SetColorTexture(1, 1, 1, 0.2)
    tile:SetScript("OnEnter", tileTooltip)
    tile:SetScript("OnLeave", function() GameTooltip:Hide() end)
    tile:SetScript("OnDragStart", startTileDrag)
    tile:SetScript("OnDragStop", function() stopTileDrag(true) end)
    tile.info = info
    info.tile = tile
    return tile
end

local function placeTiles(box, infos)
    for index, info in ipairs(infos) do
        local tile = tileFor(info)
        local column, row = (index - 1) % COLUMNS, math.floor((index - 1) / COLUMNS)
        tile:SetParent(box)
        tile:ClearAllPoints()
        tile:SetPoint("TOPLEFT", box, "TOPLEFT", 6 + column * (TILE + GAP), -6 - row * (TILE + GAP))
        copyIcon(tile.icon, info)
        tile.icon:SetDesaturated(F.IsOwnerHidden(info))
        tile.icon:SetAlpha(F.IsOwnerHidden(info) and 0.5 or 1)
        tile.placeholder:SetAlpha(F.IsOwnerHidden(info) and 0.5 or 1)
        tile:Show()
    end
    local rows = math.max(1, math.ceil(#infos / COLUMNS))
    box:SetHeight(rows * (TILE + GAP) - GAP + 12)
    box.empty:SetShown(#infos == 0)
end

-- Redraws both boxes from the collected buttons, while settings are open.
function F.RefreshButtonBoxes()
    local content = F.optionsContent
    if not content or not content:IsVisible() or F.draggingTile then return end
    for _, tile in ipairs({content.packBox:GetChildren()}) do tile:Hide() end
    for _, tile in ipairs({content.hiddenBox:GetChildren()}) do tile:Hide() end
    for _, tile in ipairs({content.minimapBox:GetChildren()}) do tile:Hide() end
    local organising = F.db.enabled
    content.off:SetShown(not organising)
    for _, frame in ipairs({content.packBox, content.hiddenBox, content.minimapBox,
            content.packBox.title, content.hiddenBox.title, content.minimapBox.title}) do
        frame:SetShown(organising)
    end
    if organising then
        local pack, hidden, minimap = {}, {}, {}
        for _, info in ipairs(F.collected or {}) do
            -- Buttons their add-on hid show in Hidden, greyed, wherever you put them.
            local list = pack
            if F.IsHidden(info) then list = hidden elseif F.IsKeptOnMinimap(info) then list = minimap end
            list[#list + 1] = info
        end
        local function byLabel(a, b) return F.ButtonLabel(a):lower() < F.ButtonLabel(b):lower() end
        table.sort(pack, byLabel)
        table.sort(hidden, byLabel)
        table.sort(minimap, byLabel)
        placeTiles(content.packBox, pack)
        placeTiles(content.hiddenBox, hidden)
        placeTiles(content.minimapBox, minimap)
    end
    -- The page grows with the boxes; the pop-up follows. (Worked out from the
    -- fixed layout above, since frame positions may not be resolved yet.)
    local height = sliderSpace() + (organising and (550 + content.packBox:GetHeight() + content.hiddenBox:GetHeight() +
        content.minimapBox:GetHeight()) or 500)
    content:SetHeight(height)
    local holder = content:GetParent()
    if holder and holder.isScrollHolder then holder:SetHeight(height) end
    -- The pop-up fits the page, but never grows past the screen; the rest scrolls.
    if F.options and holder == F.options.scrollHolder then
        F.options:SetHeight(math.min(height + POPUP_TOP + POPUP_BOTTOM, UIParent:GetHeight() - 40))
    end
end

---------------------------------------------------------------------------
-- The settings page, shown in the pop-up and in Options > AddOns
---------------------------------------------------------------------------

function F.HelpText()
    local move
    if F.UsingTitan() then
        move = "Click the Fanny Pack icon on your Titan bar; the pack drops down from it"
    else
        move = (F.HasEditMode() and "Open Edit Mode to move the pack" or "Drag the pack icon to move it") .. "; the bar opens inward"
    end
    return move .. ".\nButtons hidden by their own add-on are left out."
end

function F.BuildOptionsContent()
    if F.optionsContent then return F.optionsContent end
    local content = CreateFrame("Frame", "FannyPackOptionsContent", UIParent)
    F.optionsContent = content
    content:SetSize(360, 640)
    content:SetScript("OnShow", function() F.SyncOptions(); F.RefreshButtonBoxes() end)
    content:SetScript("OnHide", function() stopTileDrag(false) end)

    local title = content:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -20); title:SetText("|T" .. F.ICON .. ":24:24|t Fanny Pack")
    local help = content:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    content.help = help
    help:SetPoint("TOP", 0, -52)
    help:SetText(F.HelpText())

    local function checkbox(y, label, action)
        local check = CreateFrame("CheckButton", nil, content, "UICheckButtonTemplate")
        check:SetPoint("TOPLEFT", 24, y); check.Text:SetText(label)
        check:SetScript("OnClick", function(self) action(self:GetChecked() and true or false) end)
        return check
    end
    content.enabled = checkbox(-92, "Organise add-on minimap buttons", function(checked)
        F.db.enabled = checked
        if checked then F.ScanButtons(true) else F.ReleaseButtons() end
        F.RefreshButtonBoxes()
    end)
    content.vertical = checkbox(-124, "Use a vertical layout", function(checked)
        F.db.vertical = checked; F.Layout()
    end)
    content.background = checkbox(-156, "Show the bar background", function(checked)
        F.db.showBackground = checked; F.Layout()
    end)
    content.size = createSlider(content, "FannyPackSizeSlider", -220,
        F.MIN_SIZE, F.MAX_SIZE, 1, F.SetSize)
    content.spacing = createSlider(content, "FannyPackSpacingSlider", -285,
        F.MIN_SPACING, F.MAX_SPACING, 1, F.SetSpacing)
    content.rows = createSlider(content, "FannyPackRowsSlider", -350,
        F.MIN_ROWS, F.MAX_ROWS, 1, F.SetRows)
    content.minRowSize = createSlider(content, "FannyPackMinRowSizeSlider", -415,
        F.MIN_ROW_SIZE, F.MAX_ROW_SIZE, 1, F.SetMinRowSize)
    content.minRowSize:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Min row size", 1, 0.82, 0.3)
        GameTooltip:AddLine("Fewest icons in a row (the pack icon included) before the bar starts another row.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    content.minRowSize:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local scan = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
    content.scan = scan
    scan:SetSize(110, 26); scan:SetText("Scan buttons")
    scan:SetScript("OnClick", function() F.ScanButtons(true) end)
    local reset = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
    content.reset = reset
    reset:SetSize(110, 26); reset:SetText("Reset layout")
    reset:SetScript("OnClick", F.ResetLayout)

    local header = content:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    content.header = header
    header:SetText("Buttons")
    local hint = content:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    hint:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -6)
    hint:SetWidth(BOX_WIDTH)
    hint:SetJustifyH("LEFT")
    hint:SetText("Drag a button into Hidden to leave it out, or into On the minimap to keep it in its " ..
        "original place. Drag it back into In the pack to collect it.")

    content.scope = CreateFrame("CheckButton", nil, content, "UICheckButtonTemplate")
    content.scope:SetPoint("TOPLEFT", hint, "BOTTOMLEFT", -4, -4)
    content.scope.Text:SetText("Remember button choices for this character only")
    content.scope:SetScript("OnClick", function(self)
        F.db.hiddenScope = self:GetChecked() and "character" or "account"
    end)
    content.scope:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Where button choices are saved", 1, 0.82, 0.3)
        GameTooltip:AddLine("Off: what you hide or keep on the minimap applies to all your characters.", 1, 1, 1, true)
        GameTooltip:AddLine("On: your changes apply only to this character, and win over the account's.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    content.scope:SetScript("OnLeave", function() GameTooltip:Hide() end)

    content.packBox = makeBox(content, "In the pack", PACK_BORDER, content.scope, -8)
    content.hiddenBox = makeBox(content, "Hidden", HIDDEN_BORDER, content.packBox, -10)
    content.minimapBox = makeBox(content, "On the minimap", MINIMAP_BORDER, content.hiddenBox, -10)
    content.off = content:CreateFontString(nil, "OVERLAY", "GameFontDisable")
    content.off:SetPoint("TOPLEFT", content.scope, "BOTTOMLEFT", 4, -12)
    content.off:SetText("Turn on \"Organise add-on minimap buttons\" to manage buttons.")
    return content
end

-- A scroll frame filling host (less the given insets), whose child the page
-- sits centred in, so a page taller than its host scrolls instead of spilling off.
local function scrollHolderFor(host, left, top, right, bottom)
    if host.scrollHolder then return host.scrollHolder end
    local scroll = CreateFrame("ScrollFrame", nil, host, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", host, "TOPLEFT", left, -top)
    -- Room on the right for the template's scroll bar.
    scroll:SetPoint("BOTTOMRIGHT", host, "BOTTOMRIGHT", -right - 22, bottom)
    local holder = CreateFrame("Frame", nil, scroll)
    holder.isScrollHolder = true
    holder:SetSize(360, 640)
    scroll:SetScrollChild(holder)
    scroll:SetScript("OnSizeChanged", function(_, width)
        if width and width > 0 then holder:SetWidth(width) end
    end)
    host.scrollHolder = holder
    return holder
end

-- Puts the settings page into host (the pop-up or the Options page).
function F.ShowOptionsIn(host)
    local content = F.BuildOptionsContent()
    local holder
    if host == F.options then
        holder = scrollHolderFor(host, 8, POPUP_TOP, 8, POPUP_BOTTOM)
    else
        holder = scrollHolderFor(host, 0, 0, 0, 0)
    end
    content:SetParent(holder)
    content:ClearAllPoints()
    content:SetPoint("TOP", holder, "TOP", 0, 0)
    content:Show()
    F.SyncOptions()
    F.RefreshButtonBoxes()
end

-- Options > AddOns > Fanny Pack. Called once the bar is built.
function F.RegisterSettings()
    if F.settingsCategory or not (Settings and Settings.RegisterCanvasLayoutCategory) then return end
    local page = CreateFrame("Frame")
    page:Hide()
    page.OnCommit = function() end
    page.OnDefault = function() end
    page.OnRefresh = function() F.SyncOptions(); F.RefreshButtonBoxes() end
    page:SetScript("OnShow", function()
        if F.options then F.options:Hide() end
        F.ShowOptionsIn(page)
    end)
    -- The logo after the name, so the AddOns list still sorts by "Fanny Pack".
    local category = Settings.RegisterCanvasLayoutCategory(page, "Fanny Pack |T" .. F.ICON .. ":16:16|t")
    Settings.RegisterAddOnCategory(category)
    F.settingsCategory, F.settingsPage = category, page
end

function F.OpenSettingsCategory()
    if F.settingsCategory and Settings.OpenToCategory then
        local ok = pcall(Settings.OpenToCategory, F.settingsCategory:GetID())
        if ok then return end
    end
    F.ToggleOptions()
end

function F.ToggleOptions()
    if InCombatLockdown() then F.Print("Settings can be changed after combat."); return end
    if not F.options then
        local panel = CreateFrame("Frame", "FannyPackOptions", UIParent, "BackdropTemplate")
        F.options = panel
        panel:SetSize(400, 640)
        panel:SetPoint("CENTER", UIParent, "CENTER", 250, 0)
        panel:SetFrameStrata("DIALOG")
        panel:SetClampedToScreen(true)
        panel:SetMovable(true)
        panel:EnableMouse(true)
        panel:RegisterForDrag("LeftButton")
        panel:SetScript("OnDragStart", panel.StartMoving)
        panel:SetScript("OnDragStop", panel.StopMovingOrSizing)
        panel:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", edgeSize = 28,
            insets = {left = 8, right = 8, top = 8, bottom = 8}})
        local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", -4, -4)
        close:SetFrameLevel(panel:GetFrameLevel() + 20)
        panel:Hide()
    end
    if F.options:IsShown() then
        F.options:Hide()
    else
        F.options:Show()
        F.ShowOptionsIn(F.options)
    end
end
