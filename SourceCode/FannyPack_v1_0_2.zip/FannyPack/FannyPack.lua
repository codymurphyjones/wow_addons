local addonName, F = ...
local loader = CreateFrame("Frame")
F.loader = loader

loader:RegisterEvent("ADDON_LOADED")
loader:RegisterEvent("PLAYER_LOGIN")
loader:RegisterEvent("PLAYER_ENTERING_WORLD")
loader:RegisterEvent("PLAYER_REGEN_ENABLED")
loader:RegisterEvent("PLAYER_REGEN_DISABLED")
loader:RegisterEvent("UI_SCALE_CHANGED")

local MBF = "MinimapButtonForever"

local function isLoaded(name)
    local check = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
    return check and check(name) and true or false
end

-- Runs from PLAYER_LOGIN onwards, once every add-on has loaded, so Minimap
-- Button: Forever (which loads after us) can be seen.
local function initialise()
    if F.ready or F.conflict or InCombatLockdown() then return end
    -- Bring over Minimap Button: Forever's layout the first time.
    if F.db.fresh and type(MinimapButtonForeverDB) == "table" then F.ImportSettings(MinimapButtonForeverDB) end
    F.db.fresh = nil
    if isLoaded(MBF) then
        -- Both bars would fight over the same buttons.
        F.conflict = true
        F.Print("Minimap Button: Forever is also enabled. Disable it in the AddOns list and reload to use Fanny Pack.")
        return
    end
    F.BuildUI()
    if F.HasEditMode() then
        EventRegistry:RegisterCallback("EditMode.Enter", F.UpdateEditState, F)
        EventRegistry:RegisterCallback("EditMode.Exit", F.UpdateEditState, F)
        F.UpdateEditState()
    end
    F.RegisterSettings()
    F.ScanButtons()
    F.ready = true
    F.ticker = C_Timer.NewTicker(2, function()
        if not InCombatLockdown() and not F.dragging then F.ScanButtons(); F.Layout() end
    end)
    if F.titanButton then
        F.Print("Strapped on. Left-click the Fanny Pack icon on your Titan bar to show or hide icons; right-click opens settings.")
    else
        F.Print("Strapped on. Left-click shows or hides icons, right-click opens settings, and " ..
            (F.HasEditMode() and "you can move the pack in Edit Mode." or "dragging moves the pack."))
    end
end

loader:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 == addonName then
            F.LoadSettings()
            F.CreateTitanPlugin()
            SLASH_FANNYPACK1 = "/fannypack"
            SLASH_FANNYPACK2 = "/fp"
            SlashCmdList.FANNYPACK = function(message)
                if F.conflict then
                    F.Print("Minimap Button: Forever is also enabled. Disable it in the AddOns list and reload to use Fanny Pack.")
                    return
                end
                if not F.ready then F.Print("Waiting for the game to finish loading outside combat."); return end
                F.Command(message)
            end
        elseif F.ready and F.db.enabled then
            F.ScanButtons()
        end
        return
    end
    if not F.db then return end
    if event == "PLAYER_REGEN_DISABLED" then
        if F.dragging then
            F.container:SetScript("OnUpdate", nil)
            F.dragging = false
            F.dragCursorX, F.dragCursorY = nil, nil
            F.dragContainerX, F.dragContainerY = nil, nil
            F.SavePosition()
        end
        if F.options then F.options:Hide() end
        return
    end
    if event == "PLAYER_ENTERING_WORLD" and F.titanButton and not F.db.titanPlaced then
        -- Titan sets up its bars on this event too; give it a moment.
        C_Timer.After(2, F.PlaceTitanPlugin)
        C_Timer.After(6, F.PlaceTitanPlugin)
    end
    initialise()
    if not F.ready or InCombatLockdown() then return end
    if event == "UI_SCALE_CHANGED" then F.ApplyPosition() end
    F.ScanButtons()
end)
