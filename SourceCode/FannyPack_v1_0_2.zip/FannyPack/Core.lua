local _, F = ...

F.VERSION = "1.0.2"
-- Fanny Pack's logo, shipped in the add-on (Media\make_icon.py draws it).
F.ICON = "Interface\\AddOns\\FannyPack\\Media\\Icon"
F.MIN_SIZE = 20
F.MAX_SIZE = 64
F.MIN_SPACING = 0
F.MAX_SPACING = 16
F.MIN_ROWS = 1
F.MAX_ROWS = 6
F.MIN_ROW_SIZE = 1
F.MAX_ROW_SIZE = 20
F.SIZE_STEPS = {24, 32, 40, 48, 56, 64}

local DEFAULTS = {
    x = 0,
    y = 180,
    size = 32,
    spacing = 4,
    rows = 1,
    minRowSize = 4,
    vertical = false,
    expanded = false,
    showBackground = true,
    enabled = true,
}

local blockedNames = {
    AddonCompartmentFrame = true,
    BattlefieldMinimap = true,
    ExpansionLandingPageMinimapButton = true,
    GameTimeFrame = true,
    GarrisonLandingPageMinimapButton = true,
    MiniMapInstanceDifficulty = true,
    MiniMapLFGFrame = true,
    MiniMapMailFrame = true,
    MiniMapTracking = true,
    MiniMapTrackingButton = true,
    MiniMapVoiceChatFrame = true,
    MiniMapWorldMapButton = true,
    MinimapBackdrop = true,
    MinimapCluster = true,
    MinimapNorthTag = true,
    MinimapToggleButton = true,
    MinimapZoomIn = true,
    MinimapZoomOut = true,
    MinimapZoneTextButton = true,
    QueueStatusMinimapButton = true,
    QueueStatusButton = true, -- the queue eye on newer clients; Blizzard keeps moving it back

    TimeManagerClockButton = true,
}

local blockedPatterns = {
    "^QuestieFrame%d+$",
    "^GatherMatePin",
    "^HandyNotesPin",
    "^pfMiniMapPin",
}

local function isIgnoredByButtonBag(name)
    if not name or type(MBB_Ignore) ~= "table" then return false end
    for key, value in pairs(MBB_Ignore) do
        if key == name or value == name then return true end
    end
    return false
end

local function isMinimapRelative(frame)
    local current = frame and frame:GetParent()
    local depth = 0
    while current and depth < 8 do
        if current == Minimap or current == MinimapCluster then return true end
        current = current.GetParent and current:GetParent() or nil
        depth = depth + 1
    end
    if not frame or not frame.GetNumPoints then return false end
    for index = 1, frame:GetNumPoints() do
        local _, relativeTo = frame:GetPoint(index)
        current, depth = relativeTo, 0
        while current and depth < 8 do
            if current == Minimap or current == MinimapCluster then return true end
            current = current.GetParent and current:GetParent() or nil
            depth = depth + 1
        end
    end
    return false
end

function F.IsBlizzardMinimapControl(button)
    if not button then return false end
    if button == GameTimeFrame or button == TimeManagerClockButton or
            button == MiniMapTracking or button == MiniMapTrackingButton or
            button == MiniMapWorldMapButton or button == MinimapZoomIn or
            button == MinimapZoomOut then
        return true
    end
    if Minimap and (button == Minimap.ZoomIn or button == Minimap.ZoomOut or
            button == Minimap.Tracking or button == Minimap.WorldMapButton) then
        return true
    end
    return false
end

local function finite(value)
    return type(value) == "number" and value == value and math.abs(value) < 100000
end

function F.Clamp(value, low, high)
    value = tonumber(value) or low
    return math.max(low, math.min(high, value))
end

function F.Print(message)
    DEFAULT_CHAT_FRAME:AddMessage("|T" .. F.ICON .. ":14:14|t |cffffcc66Fanny Pack:|r " .. tostring(message))
end

function F.LoadSettings()
    if type(FannyPackDB) ~= "table" then FannyPackDB = {fresh = true} end
    F.db = FannyPackDB
    for key, value in pairs(DEFAULTS) do
        if F.db[key] == nil then F.db[key] = value end
    end
    F.db.x = finite(F.db.x) and F.db.x or DEFAULTS.x
    F.db.y = finite(F.db.y) and F.db.y or DEFAULTS.y
    F.db.size = math.floor(F.Clamp(F.db.size, F.MIN_SIZE, F.MAX_SIZE) + 0.5)
    F.db.spacing = math.floor(F.Clamp(F.db.spacing, F.MIN_SPACING, F.MAX_SPACING) + 0.5)
    F.db.rows = math.floor(F.Clamp(F.db.rows, F.MIN_ROWS, F.MAX_ROWS) + 0.5)
    F.db.minRowSize = math.floor(F.Clamp(F.db.minRowSize, F.MIN_ROW_SIZE, F.MAX_ROW_SIZE) + 0.5)
    if type(F.db.vertical) ~= "boolean" then F.db.vertical = DEFAULTS.vertical end
    if type(F.db.expanded) ~= "boolean" then F.db.expanded = DEFAULTS.expanded end
    if type(F.db.showBackground) ~= "boolean" then F.db.showBackground = DEFAULTS.showBackground end
    if type(F.db.enabled) ~= "boolean" then F.db.enabled = DEFAULTS.enabled end
    -- Buttons you dragged into Hidden or On the minimap. The account lists are
    -- shared by all your characters; a character's own choice for a button beats them.
    if type(FannyPackAccountDB) ~= "table" then FannyPackAccountDB = {} end
    F.account = FannyPackAccountDB
    if type(F.account.hidden) ~= "table" then F.account.hidden = {} end
    if type(F.account.minimap) ~= "table" then F.account.minimap = {} end
    if type(F.db.hidden) ~= "table" then F.db.hidden = {} end
    if type(F.db.minimap) ~= "table" then F.db.minimap = {} end
    if F.db.hiddenScope ~= "character" then F.db.hiddenScope = "account" end
end

-- Copies a Minimap Button: Forever layout (its saved settings use the same keys).
function F.ImportSettings(source)
    for key in pairs(DEFAULTS) do
        if source[key] ~= nil then F.db[key] = source[key] end
    end
    F.LoadSettings()
end

-- Whether the button's own add-on has hidden it: a LibDBIcon button whose
-- saved settings say hide, or any button its add-on called Hide() on (until
-- the add-on calls Show() again). Hidden buttons get no place in the bar.
function F.IsOwnerHidden(info)
    local db = info.button and info.button.db
    if info.isLibDBIcon and type(db) == "table" and db.hide then return true end
    return info.ownerHidden and true or false
end

-- Where you put the button: "pack" (the default), "hidden" or "minimap" (left
-- in its own place on the minimap). This character's choice if it has one,
-- else the account's. Buttons are remembered by name.
function F.GetPlacement(info)
    local name = info.button and info.button:GetName()
    if not name then return info.placement or "pack" end
    local hidden, minimap = F.db.hidden[name], F.db.minimap[name]
    if hidden == nil and minimap == nil then
        hidden, minimap = F.account.hidden[name], F.account.minimap[name]
    end
    if minimap then return "minimap" end
    if hidden then return "hidden" end
    return "pack"
end

-- Whether you dragged the button into Hidden.
function F.IsUserHidden(info)
    return F.GetPlacement(info) == "hidden"
end

-- Whether you dragged the button into On the minimap: the bar leaves it where it was.
function F.IsKeptOnMinimap(info)
    return F.GetPlacement(info) == "minimap"
end

-- Hidden either way: such a button gets no place in the bar.
function F.IsHidden(info)
    return F.IsOwnerHidden(info) or F.IsUserHidden(info)
end

-- Saves your choice for the account, or for this character only, as the
-- "this character only" setting says, then rebuilds the bar.
function F.SetPlacement(info, place)
    local name = info.button and info.button:GetName()
    if not name then
        info.placement = place -- can't be saved without a name; lasts this session
    elseif F.db.hiddenScope == "character" then
        F.db.hidden[name] = place == "hidden"
        F.db.minimap[name] = place == "minimap"
    else
        F.account.hidden[name] = place == "hidden" or nil
        F.account.minimap[name] = place == "minimap" or nil
        F.db.hidden[name], F.db.minimap[name] = nil, nil
    end
    if InCombatLockdown() then
        -- Hide or show it now; the bar closes the gap when combat ends.
        F.ApplyExpandedVisibility()
    else
        F.Layout()
    end
    F.RefreshButtonBoxes()
end

function F.SetUserHidden(info, hidden)
    F.SetPlacement(info, hidden and "hidden" or "pack")
end

-- Puts a button you keep on the minimap back where it was when collected.
function F.SendHome(info)
    if info.home then return end
    F.RestoreButton(info)
    info.home = true
    F.SetButtonShown(info.button, not F.IsOwnerHidden(info))
end

-- Takes a button off the minimap again. Its spot there is remembered afresh,
-- since you may have moved it around the minimap meanwhile.
function F.TakeFromHome(info)
    if not info.home then return end
    local button = info.button
    info.points = {}
    for index = 1, button:GetNumPoints() do
        local point, relativeTo, relativePoint, x, y = button:GetPoint(index)
        info.points[#info.points + 1] = {point, relativeTo, relativePoint, x, y}
    end
    info.home = nil
    button:SetScript("OnShow", nil)
end

-- What to call a button in settings.
function F.ButtonLabel(info)
    local button = info.button
    local data = button.dataObject
    if type(data) == "table" and type(data.label) == "string" and data.label ~= "" then return data.label end
    local name = button:GetName()
    if not name then return "Unnamed button" end
    return (name:gsub("^LibDBIcon10_", ""))
end

-- The texture showing a button's picture: its icon field, its named "Icon"
-- texture, its normal texture, or else its first artwork-layer texture
-- (borders sit in OVERLAY, backgrounds in BACKGROUND).
function F.ButtonIcon(info)
    local button = info.button
    local name = button:GetName()
    local candidates = {button.icon, button.Icon, name and _G[name .. "Icon"],
        button.GetNormalTexture and button:GetNormalTexture()}
    for _, texture in ipairs(candidates) do
        if type(texture) == "table" and texture.GetTexture and texture:GetTexture() then return texture end
    end
    for _, region in ipairs({button:GetRegions()}) do
        if region.GetObjectType and region:GetObjectType() == "Texture" and region:GetTexture() and
                region:GetDrawLayer() == "ARTWORK" then
            return region
        end
    end
end

function F.IsCollectable(button)
    if not button or button == F.launcher or button == F.container or button == F.options then return false end
    if F.IsBlizzardMinimapControl(button) then return false end
    if button.IsForbidden and button:IsForbidden() then return false end
    if button.IsProtected and button:IsProtected() then return false end
    if not button.GetObjectType or button:GetObjectType() ~= "Button" then return false end
    local name = button.GetName and button:GetName()
    if name and (blockedNames[name] or name:match("^FannyPack")) then return false end
    if isIgnoredByButtonBag(name) then return false end
    if name then
        for _, pattern in ipairs(blockedPatterns) do
            if name:match(pattern) then return false end
        end
    end
    local width, height = button:GetWidth() or 0, button:GetHeight() or 0
    if width < 8 or height < 8 or width > 80 or height > 80 then return false end
    if not isMinimapRelative(button) then return false end
    return true
end

function F.CaptureButton(button)
    local name = button:GetName()
    local icon = button.icon
    local iconR, iconG, iconB, iconA
    if icon and icon.GetVertexColor then iconR, iconG, iconB, iconA = icon:GetVertexColor() end
    local info = {
        button = button,
        parent = button:GetParent(),
        width = button:GetWidth(),
        height = button:GetHeight(),
        scale = button:GetScale(),
        strata = button:GetFrameStrata(),
        level = button:GetFrameLevel(),
        points = {},
        alpha = button:GetAlpha(),
        onShow = button:GetScript("OnShow"),
        showOnMouseover = button.showOnMouseover,
        icon = icon,
        iconR = iconR,
        iconG = iconG,
        iconB = iconB,
        iconA = iconA,
        iconAlpha = icon and icon.GetAlpha and icon:GetAlpha() or nil,
        iconDesaturated = icon and icon.IsDesaturated and icon:IsDesaturated() or nil,
        isLibDBIcon = name and name:match("^LibDBIcon10_") and true or false,
        -- Hidden when collected means hidden by its add-on, unless LibDBIcon
        -- settings say it should show (a button-bag add-on hid it instead).
        ownerHidden = not button:IsShown() and
            not (type(button.db) == "table" and button.db.hide == false),
        order = name or tostring(button),
    }
    for index = 1, button:GetNumPoints() do
        local point, relativeTo, relativePoint, x, y = button:GetPoint(index)
        info.points[#info.points + 1] = {point, relativeTo, relativePoint, x, y}
    end
    return info
end

function F.RestoreButton(info)
    local button = info and info.button
    if not button then return end
    if info.slot then info.slot:Hide() end
    if info.isLibDBIcon then
        if button.SetFixedFrameLevel then button:SetFixedFrameLevel(false) end
        if button.SetFixedFrameStrata then button:SetFixedFrameStrata(false) end
    end
    button:SetParent(info.parent)
    button:ClearAllPoints()
    button:SetSize(info.width, info.height)
    button:SetScale(info.scale)
    button:SetAlpha(info.alpha or 1)
    button:SetFrameStrata(info.strata)
    button:SetFrameLevel(info.level)
    if info.isLibDBIcon then
        if button.SetFixedFrameLevel then button:SetFixedFrameLevel(true) end
        if button.SetFixedFrameStrata then button:SetFixedFrameStrata(true) end
    end
    button.showOnMouseover = info.showOnMouseover
    button:SetScript("OnShow", info.onShow)
    if info.isLibDBIcon and button.fadeOut and button.fadeOut.SetToFinalAlpha then
        button.fadeOut:SetToFinalAlpha(true)
    end
    if info.icon and info.icon.SetVertexColor and info.iconR then
        info.icon:SetVertexColor(info.iconR, info.iconG, info.iconB, info.iconA or 1)
        if info.icon.SetAlpha and info.iconAlpha then info.icon:SetAlpha(info.iconAlpha) end
        if info.icon.SetDesaturated and info.iconDesaturated ~= nil then
            info.icon:SetDesaturated(info.iconDesaturated)
        end
    end
    for _, point in ipairs(info.points) do
        button:SetPoint(point[1], point[2], point[3], point[4], point[5])
    end
end

function F.BrightenButton(info)
    local button = info and info.button
    if not button then return end
    if button.fadeOut and button.fadeOut.Stop then button.fadeOut:Stop() end
    if info.isLibDBIcon and button.fadeOut and button.fadeOut.SetToFinalAlpha then
        button.fadeOut:SetToFinalAlpha(false)
    end
    button.showOnMouseover = false
    button:SetAlpha(1)
    if info.icon then
        if info.icon.SetAlpha then info.icon:SetAlpha(1) end
        if info.icon.SetVertexColor then info.icon:SetVertexColor(1, 1, 1, 1) end
        if info.icon.SetDesaturated then info.icon:SetDesaturated(false) end
    end
end

function F.SetSize(value)
    if InCombatLockdown() then
        F.Print("Icon sizes can be changed after combat.")
        return
    end
    F.db.size = math.floor(F.Clamp(value, F.MIN_SIZE, F.MAX_SIZE) + 0.5)
    F.Layout()
    F.SyncOptions()
end

function F.SetSpacing(value)
    if InCombatLockdown() then return end
    F.db.spacing = math.floor(F.Clamp(value, F.MIN_SPACING, F.MAX_SPACING) + 0.5)
    F.Layout()
    F.SyncOptions()
end

function F.SetRows(value)
    if InCombatLockdown() then return end
    F.db.rows = math.floor(F.Clamp(value, F.MIN_ROWS, F.MAX_ROWS) + 0.5)
    F.Layout()
    F.SyncOptions()
end

function F.SetMinRowSize(value)
    if InCombatLockdown() then return end
    F.db.minRowSize = math.floor(F.Clamp(value, F.MIN_ROW_SIZE, F.MAX_ROW_SIZE) + 0.5)
    F.Layout()
    F.SyncOptions()
end

function F.ResetLayout()
    if InCombatLockdown() then return end
    F.db.x, F.db.y = DEFAULTS.x, DEFAULTS.y
    F.db.size, F.db.spacing = DEFAULTS.size, DEFAULTS.spacing
    F.db.rows, F.db.minRowSize = DEFAULTS.rows, DEFAULTS.minRowSize
    F.db.vertical, F.db.expanded, F.db.showBackground, F.db.enabled = false, false, true, true
    F.ApplyPosition()
    F.ScanButtons()
    F.Layout()
    F.SyncOptions()
    F.Print("Layout reset.")
end

function F.Command(message)
    local command, value = tostring(message or ""):lower():match("^%s*(%S*)%s*(.-)%s*$")
    if command == "" or command == "settings" then
        F.ToggleOptions()
    elseif command == "horizontal" then
        F.db.vertical = false; F.Layout(); F.SyncOptions()
    elseif command == "vertical" then
        F.db.vertical = true; F.Layout(); F.SyncOptions()
    elseif command == "size" and tonumber(value) then
        F.SetSize(value)
    elseif command == "spacing" and tonumber(value) then
        F.SetSpacing(value)
    elseif command == "rows" and tonumber(value) then
        F.SetRows(value)
    elseif command == "minrow" and tonumber(value) then
        F.SetMinRowSize(value)
    elseif command == "scan" then
        F.ScanButtons(true)
    elseif command == "reset" then
        F.ResetLayout()
    elseif command == "status" then
        local count, byAddon, byYou, kept = F.collected and #F.collected or 0, 0, 0, 0
        for _, info in ipairs(F.collected or {}) do
            if F.IsOwnerHidden(info) then byAddon = byAddon + 1
            elseif F.IsUserHidden(info) then byYou = byYou + 1
            elseif F.IsKeptOnMinimap(info) then kept = kept + 1 end
        end
        F.Print("Version " .. F.VERSION .. "; " .. count .. " button(s), " .. byAddon .. " hidden by their add-ons, " ..
            byYou .. " hidden by you, " .. kept .. " kept on the minimap (" ..
            (F.db.hiddenScope == "character" and "this character" or "account") .. "); " ..
            (F.db.vertical and "vertical" or "horizontal") .. "; size " .. F.db.size .. "; " .. F.db.rows .. " row(s)" ..
            (F.db.rows > 1 and (", at least " .. F.db.minRowSize .. " per row") or "") .. "; Titan " ..
            (not F.titanButton and "not loaded" or F.UsingTitan() and "on a bar" or "loaded, but not on a bar") .. ".")
    elseif command == "icons" then
        -- What each button's icon is, for working out why one shows blank in settings.
        for _, info in ipairs(F.collected or {}) do
            local ok, source = pcall(F.ButtonIcon, info)
            local detail = "no icon found"
            if not ok then
                detail = "error: " .. tostring(source)
            elseif source then
                local atlas = source.GetAtlas and source:GetAtlas()
                local masks = source.GetNumMaskTextures and source:GetNumMaskTextures() or 0
                detail = (source:GetName() or source:GetDebugName() or "?") .. " " .. source:GetDrawLayer() ..
                    (atlas and (" atlas " .. tostring(atlas)) or (" texture " .. tostring(source:GetTexture()))) ..
                    " coords " .. table.concat({source:GetTexCoord()}, ",") ..
                    " alpha " .. tostring(source:GetAlpha()) .. " shown " .. tostring(source:IsShown()) ..
                    " masks " .. masks
            end
            F.Print(F.ButtonLabel(info) .. ": " .. detail)
        end
    elseif command == "options" then
        F.OpenSettingsCategory()
    else
        F.Print("Commands: /fp, /fp options, /fp horizontal, /fp vertical, /fp size 40, /fp spacing 4, /fp rows 2, /fp minrow 4, /fp scan, /fp reset, /fp status, /fp icons")
    end
end
